-- Aura Artisan Cafe Management System Database Schema
-- Enterprise Application Development

CREATE DATABASE IF NOT EXISTS cafe_db;
USE cafe_db;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('ADMIN', 'CASHIER') NOT NULL DEFAULT 'CASHIER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- 4. Orders Table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    customer_name VARCHAR(100) DEFAULT 'Walk-in Customer',
    customer_phone VARCHAR(20) DEFAULT '',
    user_id INT NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    tax_amount DECIMAL(10, 2) DEFAULT 0.00,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    net_amount DECIMAL(10, 2) NOT NULL,
    payment_type VARCHAR(20) DEFAULT 'CASH',
    payment_status VARCHAR(20) DEFAULT 'COMPLETED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 5. Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Seed Data

-- Insert Default Users (Password: admin123, cashier123)
INSERT INTO users (username, password, full_name, role) VALUES 
('admin', 'admin123', 'System Administrator', 'ADMIN'),
('cashier', 'cashier123', 'Sarah Jenkins', 'CASHIER')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);

-- Insert Default Categories
INSERT INTO categories (id, name, description) VALUES 
(1, 'Espresso & Coffee', 'Rich freshly brewed hot and cold coffee beverages'),
(2, 'Cold Drinks & Teas', 'Refreshing iced teas, fruit smoothies, and chillers'),
(3, 'Bakery & Pastries', 'Freshly baked croissants, muffins, and cakes'),
(4, 'Sandwiches & Snacks', 'Delicious hot sandwiches, wraps, and quick bites')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Insert Default Products (Prices in Rupees)
INSERT INTO products (id, category_id, name, description, price, stock, image_path) VALUES 
(1, 1, 'Classic Espresso', 'Single shot of intense aromatic espresso', 450.00, 50, 'product_images/espresso.png'),
(2, 1, 'Caffe Latte', 'Smooth espresso layered with steamed milk and foam', 650.00, 45, 'product_images/latte.png'),
(3, 1, 'Cappuccino', 'Rich espresso topped with velvety milk foam and cocoa dusting', 620.00, 40, 'product_images/cappuccino.png'),
(4, 1, 'Caramel Macchiato', 'Espresso with vanilla syrup, steamed milk, and caramel drizzle', 750.00, 35, 'product_images/macchiato.png'),
(5, 2, 'Iced Lemon Tea', 'Fresh black tea brewed with lemon and fresh mint', 480.00, 60, 'product_images/iced_tea.png'),
(6, 2, 'Berry Smoothie', 'Blended fresh strawberries, blueberries, and yogurt', 850.00, 30, 'product_images/smoothie.png'),
(7, 3, 'Butter Croissant', 'Flaky, buttery French croissant baked fresh daily', 420.00, 25, 'product_images/croissant.png'),
(8, 3, 'Blueberry Muffin', 'Moist muffin packed with fresh blueberries', 390.00, 30, 'product_images/muffin.png'),
(9, 3, 'Chocolate Cheesecake', 'Decadent dark chocolate cheesecake with berry topping', 890.00, 20, 'product_images/cheesecake.png'),
(10, 4, 'Club Sandwich', 'Double decker toasted bread with chicken, cheese, and lettuce', 1150.00, 20, 'product_images/sandwich.png')
ON DUPLICATE KEY UPDATE name=VALUES(name), price=VALUES(price), stock=VALUES(stock), image_path=VALUES(image_path);

-- Insert Sample Orders for Reporting (Amounts in Rupees)
INSERT INTO orders (id, order_number, customer_name, customer_phone, user_id, subtotal, tax_amount, discount_amount, net_amount, payment_type, payment_status, created_at) VALUES 
(101, 'ORD-20261001-001', 'Alex Mercer', '0771234567', 2, 1720.00, 86.00, 0.00, 1806.00, 'CASH', 'COMPLETED', NOW() - INTERVAL 1 DAY),
(102, 'ORD-20261001-002', 'Emily Clarke', '0719876543', 2, 2390.00, 119.50, 100.00, 2409.50, 'CARD', 'COMPLETED', NOW() - INTERVAL 1 DAY),
(103, 'ORD-20261002-001', 'David Miller', '0754443322', 2, 1460.00, 73.00, 0.00, 1533.00, 'CASH', 'COMPLETED', NOW())
ON DUPLICATE KEY UPDATE order_number=VALUES(order_number);

-- Insert Sample Order Items
INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES 
(101, 2, 2, 650.00, 1300.00),
(101, 7, 1, 420.00, 420.00),
(102, 4, 2, 750.00, 1500.00),
(102, 9, 1, 890.00, 890.00),
(103, 3, 1, 620.00, 620.00),
(103, 8, 1, 390.00, 390.00),
(103, 1, 1, 450.00, 450.00)
ON DUPLICATE KEY UPDATE quantity=VALUES(quantity), unit_price=VALUES(unit_price), subtotal=VALUES(subtotal);
