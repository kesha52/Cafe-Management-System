# Aura Artisan Cafe Management System & POS Suite
**Enterprise Application Development (EAD)**  
*Advanced Sales, Point of Sale, Inventory & Decision Reporting Suite*

---

## ☕ Project Overview
**Aura Artisan Cafe Management System** is an enterprise desktop application developed with **Java Swing**, **MySQL**, and **JasperReports**. Specifically focused on the **Sales** domain, it provides a comprehensive Point-of-Sale (POS) environment with **real high-resolution product imagery**, real-time inventory management, transactional receipt generation, executive sales dashboard, and Jasper decision-making reporting with multi-table database queries in Sri Lankan / South Asian Rupees (**Rs.**).

---

## 📋 Key Deliverables & Feature Highlights

| Feature Area | Implementation Highlights |
| :--- | :--- |
| **User Interface** | Modern FlatLaf design, Sales POS transaction screen with **real product images**, search, live cart calculation in **Rupees (Rs.)**, category filters, and printable thermal receipt dialog. |
| **Reports** | **JasperReports (`sales_report.jrxml`)** joining **5 database tables** (`orders`, `order_items`, `products`, `categories`, `users`). Features interactive JasperViewer preview and one-click PDF export in Rupees. |
| **Application of Standards** | Strict adherence to **Singleton Pattern** (`DBConnection`), **DAO Pattern** (`UserDAO`, `CategoryDAO`, `ProductDAO`, `OrderDAO`, `ReportDAO`), transactional ACID safety with commit/rollback, and robust input validation. |
| **Scope Covered** | Full sales lifecycle: User Authentication, Inventory tracking, Categorization, Dynamic POS Checkout, Receipt Printing, Sales History, Daily KPI Analytics. |
| **Deployment** | Packaged executable Uber JAR (`target/CafeManagementSystem-1.0-SNAPSHOT.jar`), one-click batch scripts (`run.bat`, `setup_database.bat`, `build.bat`), and self-contained asset generation. |

---

## 🛠️ Technology Stack
- **Programming Language**: Java 17+
- **GUI Framework**: Java Swing with FlatLaf Modern Theme
- **Database (DBMS)**: MySQL 8.0+ (Port: `3306`, User: `root`, Password: `ke1234`)
- **Currency**: Rupees (**Rs.**)
- **Reporting Engine**: JasperReports 6.20.6 with OpenPDF
- **Build Tool**: Apache Maven

---

## 🔑 Default Login Credentials

| Role | Username | Password | Access Rights |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin` | `admin123` | Full Access: POS, Inventory, Categories, Reports, Dashboard |
| **Cashier** | `cashier` | `cashier123` | Operational Access: POS & Billing, Receipts, Product Catalog |

---

## 🚀 Quick Start / How to Run

### Method 1: One-Click Launch (Recommended)
1. Ensure MySQL is running on port 3306.
2. Double-click `setup_database.bat` to automatically create and seed the `cafe_db` database.
3. Double-click `run.bat` to launch the application!

### Method 2: Command Line (Maven / Java)
```bash
# 1. Setup MySQL Database
mysql -u root -pke1234 < schema.sql

# 2. Build executable JAR
mvn clean package -DskipTests

# 3. Run application
java -jar target/CafeManagementSystem-1.0-SNAPSHOT.jar
```

---

## 🗄️ Database Schema & Relational Design

The database `cafe_db` consists of 5 normalized relational tables:
1. **`users`**: User accounts, passwords, full names, and security roles (`ADMIN`, `CASHIER`).
2. **`categories`**: Product classifications (*Espresso & Coffee*, *Cold Drinks & Teas*, *Bakery & Pastries*, *Sandwiches & Snacks*).
3. **`products`**: Product inventory items, pricing in **Rupees (Rs.)**, stock quantity, and real image paths.
4. **`orders`**: Sales transactions header, customer details, tax (5%), discount, net grand total, payment type, cashier ID.
5. **`order_items`**: Line items for each transaction recording product, quantity, unit price, and subtotal.

---

## 📐 Design Patterns Implemented

### 1. Singleton Pattern (`DBConnection.java`)
Ensures only one database connection pool manager is created throughout the application lifecycle to optimize database resources:
```java
DBConnection.getInstance().getConnection();
```

### 2. Data Access Object (DAO) Pattern
Separates business and UI logic from low-level database operations:
- `UserDAO.java`: User authentication and authorization.
- `CategoryDAO.java`: Category CRUD operations.
- `ProductDAO.java`: Product inventory, search, and stock level updates.
- `OrderDAO.java`: Transactional order placement with automatic stock reduction, rollback safety, and dashboard statistics.
- `ReportDAO.java`: Multi-table analytical sales queries for JasperReports.

### 3. Factory / Utility Patterns
- `JasperReportManager.java`: Compiles `.jrxml` templates and generates JasperPrint / PDF exports.
- `ImageUtils.java`: Image caching, dynamic scaling, and fallback image generation.
- `ValidationUtils.java`: Centralized input verification and user dialog alerts.
