package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class MainFrame extends JFrame {

    private final User currentUser;

    private CardLayout cardLayout;
    private JPanel contentPanel;

    private DashboardPanel dashboardPanel;
    private POSPanel posPanel;
    private ProductManagementPanel productPanel;
    private CategoryManagementPanel categoryPanel;
    private SalesReportsPanel reportsPanel;

    private final Map<String, JButton> navButtons = new HashMap<>();

    public MainFrame(User user) {
        this.currentUser = user;

        setTitle("Aura Artisan Cafe Management System - Sales & POS Suite");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1240, 780);
        setMinimumSize(new Dimension(1080, 680));
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        JPanel rootPanel = new JPanel(new BorderLayout());

        // ================= LEFT SIDEBAR =================
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(230, 0));
        sidebar.setBackground(new Color(44, 29, 17));

        // Sidebar Brand Header
        JPanel brandPanel = new JPanel(new BorderLayout(0, 5));
        brandPanel.setOpaque(false);
        brandPanel.setBorder(new EmptyBorder(25, 20, 20, 20));

        JLabel lblLogo = new JLabel("☕ AURA CAFE");
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblLogo.setForeground(new Color(245, 235, 224));

        JLabel lblSubLogo = new JLabel("Artisan Sales & POS Suite");
        lblSubLogo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubLogo.setForeground(new Color(212, 163, 115));

        brandPanel.add(lblLogo, BorderLayout.NORTH);
        brandPanel.add(lblSubLogo, BorderLayout.SOUTH);
        sidebar.add(brandPanel, BorderLayout.NORTH);

        // Sidebar Navigation Links
        JPanel navMenu = new JPanel();
        navMenu.setLayout(new BoxLayout(navMenu, BoxLayout.Y_AXIS));
        navMenu.setOpaque(false);
        navMenu.setBorder(new EmptyBorder(10, 12, 10, 12));

        navMenu.add(createNavButton("Dashboard", "DASHBOARD", "📊"));
        navMenu.add(Box.createVerticalStrut(6));
        navMenu.add(createNavButton("Point of Sale (POS)", "POS", "🛒"));
        navMenu.add(Box.createVerticalStrut(6));
        navMenu.add(createNavButton("Products & Stock", "PRODUCTS", "☕"));
        navMenu.add(Box.createVerticalStrut(6));
        navMenu.add(createNavButton("Categories", "CATEGORIES", "📁"));
        navMenu.add(Box.createVerticalStrut(6));
        navMenu.add(createNavButton("Reports (Jasper)", "REPORTS", "📈"));

        sidebar.add(navMenu, BorderLayout.CENTER);

        // Sidebar Footer (User Info & Logout)
        JPanel userFooter = new JPanel(new BorderLayout(0, 8));
        userFooter.setOpaque(false);
        userFooter.setBorder(new EmptyBorder(15, 18, 20, 18));

        JPanel userCard = new JPanel(new GridLayout(2, 1, 0, 2));
        userCard.setOpaque(false);

        JLabel lblUserName = new JLabel("👤 " + currentUser.getFullName());
        lblUserName.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblUserName.setForeground(Color.WHITE);

        JLabel lblUserRole = new JLabel("Role: " + currentUser.getRole());
        lblUserRole.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblUserRole.setForeground(new Color(212, 163, 115));

        userCard.add(lblUserName);
        userCard.add(lblUserRole);

        JButton btnLogout = new JButton("Log Out");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnLogout.setBackground(new Color(75, 45, 30));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> logout());

        userFooter.add(userCard, BorderLayout.NORTH);
        userFooter.add(btnLogout, BorderLayout.SOUTH);
        sidebar.add(userFooter, BorderLayout.SOUTH);

        // ================= CENTER CONTENT AREA =================
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        // Panels
        dashboardPanel = new DashboardPanel(currentUser, this::switchView);
        posPanel = new POSPanel(currentUser, this);
        productPanel = new ProductManagementPanel();
        categoryPanel = new CategoryManagementPanel();
        reportsPanel = new SalesReportsPanel();

        contentPanel.add(dashboardPanel, "DASHBOARD");
        contentPanel.add(posPanel, "POS");
        contentPanel.add(productPanel, "PRODUCTS");
        contentPanel.add(categoryPanel, "CATEGORIES");
        contentPanel.add(reportsPanel, "REPORTS");

        rootPanel.add(sidebar, BorderLayout.WEST);
        rootPanel.add(contentPanel, BorderLayout.CENTER);

        setContentPane(rootPanel);

        // Default initial view
        switchView("DASHBOARD");
    }

    private JButton createNavButton(String text, String cardKey, String icon) {
        JButton btn = new JButton(icon + "  " + text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(new Color(220, 215, 205));
        btn.setBackground(new Color(44, 29, 17));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(10, 14, 10, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        btn.addActionListener(e -> switchView(cardKey));
        navButtons.put(cardKey, btn);
        return btn;
    }

    public void switchView(String cardKey) {
        // Highlight active navigation button
        for (Map.Entry<String, JButton> entry : navButtons.entrySet()) {
            if (entry.getKey().equals(cardKey)) {
                entry.getValue().setBackground(new Color(92, 58, 33));
                entry.getValue().setForeground(Color.WHITE);
            } else {
                entry.getValue().setBackground(new Color(44, 29, 17));
                entry.getValue().setForeground(new Color(220, 215, 205));
            }
        }

        // Show card and refresh its state
        cardLayout.show(contentPanel, cardKey);

        if ("DASHBOARD".equals(cardKey)) {
            dashboardPanel.refreshDashboard();
        } else if ("POS".equals(cardKey)) {
            posPanel.refreshProducts();
        }
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to log out?", "Logout", 
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            SwingUtilities.invokeLater(() -> {
                LoginFrame login = new LoginFrame();
                login.setVisible(true);
            });
        }
    }
}
