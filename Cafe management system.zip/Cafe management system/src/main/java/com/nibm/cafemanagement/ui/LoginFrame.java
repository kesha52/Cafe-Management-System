package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.UserDAO;
import com.nibm.cafemanagement.model.User;
import com.nibm.cafemanagement.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

public class LoginFrame extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnReset;
    private final UserDAO userDAO = new UserDAO();

    public LoginFrame() {
        setTitle("Login - Aura Artisan Cafe Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 520);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {
        JPanel mainContainer = new JPanel(new GridLayout(1, 2));

        // Left Branding Panel (Rich Cafe Illustration / Gradient)
        JPanel leftBrandPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(44, 29, 17), getWidth(), getHeight(), new Color(92, 58, 33));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Decorative Coffee Bean / Circles
                g2.setColor(new Color(255, 255, 255, 12));
                g2.fillOval(30, 40, 180, 180);
                g2.fillOval(200, 240, 220, 220);

                // Coffee Cup Icon
                g2.setColor(new Color(212, 163, 115));
                int cx = getWidth() / 2;
                int cy = 160;
                
                // Steam
                g2.setStroke(new BasicStroke(3f));
                g2.drawArc(cx - 15, cy - 40, 15, 25, 0, 180);
                g2.drawArc(cx + 5, cy - 45, 15, 25, 180, -180);
                
                // Cup
                g2.fillRoundRect(cx - 35, cy - 10, 70, 50, 16, 16);
                g2.drawArc(cx + 25, cy - 5, 22, 30, 270, 180);
                g2.fillRoundRect(cx - 45, cy + 42, 90, 8, 6, 6);

                g2.dispose();
            }
        };
        leftBrandPanel.setLayout(new BoxLayout(leftBrandPanel, BoxLayout.Y_AXIS));
        leftBrandPanel.setBorder(new EmptyBorder(220, 40, 40, 40));

        JLabel lblTitle = new JLabel("AURA ARTISAN CAFE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(245, 235, 224));
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Premium Coffee & POS Suite");
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        lblSubtitle.setForeground(new Color(212, 163, 115));
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblTagline = new JLabel("<html><center>Freshly Brewed Excellence<br>Sales & Inventory Management</center></html>");
        lblTagline.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblTagline.setForeground(new Color(200, 180, 160));
        lblTagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        leftBrandPanel.add(Box.createVerticalStrut(20));
        leftBrandPanel.add(lblTitle);
        leftBrandPanel.add(Box.createVerticalStrut(8));
        leftBrandPanel.add(lblSubtitle);
        leftBrandPanel.add(Box.createVerticalGlue());
        leftBrandPanel.add(lblTagline);

        // Right Form Panel
        JPanel rightFormPanel = new JPanel();
        rightFormPanel.setBackground(Color.WHITE);
        rightFormPanel.setLayout(new GridBagLayout());
        rightFormPanel.setBorder(new EmptyBorder(40, 45, 40, 45));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 0, 8, 0);
        gbc.gridx = 0;
        gbc.weightx = 1.0;

        // Form Heading
        JLabel lblWelcome = new JLabel("Welcome Back");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblWelcome.setForeground(new Color(44, 29, 17));
        gbc.gridy = 0;
        rightFormPanel.add(lblWelcome, gbc);

        JLabel lblInstruction = new JLabel("Please enter your credentials to login");
        lblInstruction.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblInstruction.setForeground(Color.GRAY);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 20, 0);
        rightFormPanel.add(lblInstruction, gbc);

        // Username
        gbc.insets = new Insets(6, 0, 4, 0);
        JLabel lblUser = new JLabel("Username");
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblUser.setForeground(new Color(70, 70, 70));
        gbc.gridy = 2;
        rightFormPanel.add(lblUser, gbc);

        txtUsername = new JTextField("admin");
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsername.setPreferredSize(new Dimension(300, 38));
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 12, 0);
        rightFormPanel.add(txtUsername, gbc);

        // Password
        gbc.insets = new Insets(6, 0, 4, 0);
        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPass.setForeground(new Color(70, 70, 70));
        gbc.gridy = 4;
        rightFormPanel.add(lblPass, gbc);

        txtPassword = new JPasswordField("admin123");
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setPreferredSize(new Dimension(300, 38));
        gbc.gridy = 5;
        gbc.insets = new Insets(0, 0, 20, 0);
        rightFormPanel.add(txtPassword, gbc);

        // Buttons Panel
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 12, 0));
        btnPanel.setOpaque(false);

        btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(new Color(92, 58, 33));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.setPreferredSize(new Dimension(140, 42));

        btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnReset.setBackground(new Color(230, 230, 230));
        btnReset.setForeground(Color.DARK_GRAY);
        btnReset.setFocusPainted(false);
        btnReset.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnPanel.add(btnLogin);
        btnPanel.add(btnReset);

        gbc.gridy = 6;
        gbc.insets = new Insets(5, 0, 15, 0);
        rightFormPanel.add(btnPanel, gbc);

        // Quick Credentials Helper Info
        JPanel infoPanel = new JPanel();
        infoPanel.setBackground(new Color(245, 243, 238));
        infoPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 215, 200)),
            new EmptyBorder(8, 10, 8, 10)
        ));
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

        JLabel lblHint1 = new JLabel("Default Admin: admin | admin123");
        lblHint1.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblHint1.setForeground(new Color(100, 100, 100));

        JLabel lblHint2 = new JLabel("Default Cashier: cashier | cashier123");
        lblHint2.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblHint2.setForeground(new Color(100, 100, 100));

        infoPanel.add(lblHint1);
        infoPanel.add(Box.createVerticalStrut(3));
        infoPanel.add(lblHint2);

        gbc.gridy = 7;
        gbc.insets = new Insets(10, 0, 0, 0);
        rightFormPanel.add(infoPanel, gbc);

        // Add both to container
        mainContainer.add(leftBrandPanel);
        mainContainer.add(rightFormPanel);
        setContentPane(mainContainer);

        // Action Listeners
        btnLogin.addActionListener(e -> performLogin());
        btnReset.addActionListener(e -> {
            txtUsername.setText("");
            txtPassword.setText("");
            txtUsername.requestFocus();
        });

        // Enter key submits form
        KeyAdapter enterKeyAdapter = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    performLogin();
                }
            }
        };
        txtUsername.addKeyListener(enterKeyAdapter);
        txtPassword.addKeyListener(enterKeyAdapter);
    }

    private void performLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();

        if (ValidationUtils.isEmpty(username)) {
            ValidationUtils.showWarning("Login Validation", "Please enter your username.");
            txtUsername.requestFocus();
            return;
        }

        if (ValidationUtils.isEmpty(password)) {
            ValidationUtils.showWarning("Login Validation", "Please enter your password.");
            txtPassword.requestFocus();
            return;
        }

        try {
            User user = userDAO.authenticate(username, password);
            if (user != null) {
                // Login successful
                dispose();
                SwingUtilities.invokeLater(() -> {
                    MainFrame mainFrame = new MainFrame(user);
                    mainFrame.setVisible(true);
                });
            } else {
                ValidationUtils.showError("Authentication Failed", "Invalid username or password.\nPlease check your credentials.");
                txtPassword.setText("");
                txtPassword.requestFocus();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Unable to connect to database:\n" + ex.getMessage());
        }
    }
}
