package com.nibm.cafemanagement.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * Singleton Pattern implementation for Database Connection.
 * Ensures a single connection instance is reused across Data Access Objects (DAOs).
 */
public class DBConnection {

    private static DBConnection instance;
    private Connection connection;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/cafe_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static String dbUser = "root";
    private static String dbPassword = "ke1234";

    private DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(DB_URL, dbUser, dbPassword);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL Driver not found: " + e.getMessage());
            showError("Database Driver Error", "MySQL JDBC Driver not found on classpath.");
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            // Try secondary password format if specified by user environment
            try {
                this.connection = DriverManager.getConnection(DB_URL, dbUser, "3306-ke1234");
            } catch (SQLException ex) {
                showError("Database Connection Error", 
                    "Unable to connect to MySQL database.\nPlease ensure MySQL service is running on port 3306 with password 'ke1234'.\n\nError: " + e.getMessage());
            }
        }
    }

    public static synchronized DBConnection getInstance() {
        try {
            if (instance == null || instance.getConnection() == null || instance.getConnection().isClosed()) {
                instance = new DBConnection();
            }
        } catch (SQLException e) {
            instance = new DBConnection();
        }
        return instance;
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                try {
                    connection = DriverManager.getConnection(DB_URL, dbUser, dbPassword);
                } catch (SQLException e) {
                    connection = DriverManager.getConnection(DB_URL, dbUser, "3306-ke1234");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error re-establishing connection: " + e.getMessage());
        }
        return connection;
    }

    public static void setCredentials(String user, String password) {
        dbUser = user;
        dbPassword = password;
        if (instance != null) {
            try {
                if (instance.connection != null && !instance.connection.isClosed()) {
                    instance.connection.close();
                }
            } catch (SQLException ignored) {}
            instance = null;
        }
    }

    private void showError(String title, String message) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }
}
