package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.CategoryDAO;
import com.nibm.cafemanagement.dao.OrderDAO;
import com.nibm.cafemanagement.dao.ProductDAO;
import com.nibm.cafemanagement.model.*;
import com.nibm.cafemanagement.ui.components.ProductCard;
import com.nibm.cafemanagement.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class POSPanel extends JPanel {

    private final User currentUser;
    private final Frame parentFrame;

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    // Data lists
    private List<Product> currentProductList = new ArrayList<>();
    private final List<OrderItem> cartItems = new ArrayList<>();

    // UI Components - Catalog (Left)
    private JPanel categoryTabsPanel;
    private JTextField txtSearch;
    private JPanel productGridPanel;
    private JScrollPane productScrollPane;
    private int selectedCategoryId = 0;

    // UI Components - Cart & Billing (Right)
    private JTable cartTable;
    private DefaultTableModel cartTableModel;
    private JTextField txtCustomerName;
    private JTextField txtCustomerPhone;
    private JLabel lblSubtotal;
    private JLabel lblTax;
    private JTextField txtDiscount;
    private JLabel lblGrandTotal;
    private JComboBox<String> cmbPaymentType;
    private JTextField txtAmountPaid;
    private JLabel lblChangeDue;
    private JButton btnPlaceOrder;
    private JButton btnClearCart;

    private static final double TAX_RATE = 0.05; // 5% VAT / Sales Tax

    public POSPanel(User user, Frame parent) {
        this.currentUser = user;
        this.parentFrame = parent;

        setLayout(new BorderLayout(15, 0));
        setBackground(new Color(248, 246, 242));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        initComponents();
        loadCategories();
        loadProducts(0, "");
    }

    private void initComponents() {
        // ================= LEFT: PRODUCT CATALOG =================
        JPanel catalogPanel = new JPanel(new BorderLayout(0, 10));
        catalogPanel.setOpaque(false);

        // Header / Search Bar & Category Filters
        JPanel topFilterPanel = new JPanel(new BorderLayout(10, 8));
        topFilterPanel.setOpaque(false);

        // Search Field
        JPanel searchBox = new JPanel(new BorderLayout(8, 0));
        searchBox.setOpaque(false);
        JLabel lblSearchIcon = new JLabel("🔍 Search:");
        lblSearchIcon.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblSearchIcon.setForeground(new Color(44, 29, 17));

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setPreferredSize(new Dimension(220, 32));
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterProducts(); }
            public void removeUpdate(DocumentEvent e) { filterProducts(); }
            public void changedUpdate(DocumentEvent e) { filterProducts(); }
        });

        searchBox.add(lblSearchIcon, BorderLayout.WEST);
        searchBox.add(txtSearch, BorderLayout.CENTER);

        // Category Filter Buttons Bar
        categoryTabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        categoryTabsPanel.setOpaque(false);

        topFilterPanel.add(searchBox, BorderLayout.NORTH);
        topFilterPanel.add(categoryTabsPanel, BorderLayout.SOUTH);
        catalogPanel.add(topFilterPanel, BorderLayout.NORTH);

        // Product Cards Grid
        productGridPanel = new JPanel(new GridLayout(0, 3, 12, 12));
        productGridPanel.setBackground(new Color(248, 246, 242));
        productGridPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

        productScrollPane = new JScrollPane(productGridPanel);
        productScrollPane.setBorder(BorderFactory.createLineBorder(new Color(230, 225, 218)));
        productScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        catalogPanel.add(productScrollPane, BorderLayout.CENTER);

        // ================= RIGHT: ACTIVE ORDER / CART & CHECKOUT =================
        JPanel checkoutPanel = new JPanel(new BorderLayout(0, 10));
        checkoutPanel.setPreferredSize(new Dimension(420, 0));
        checkoutPanel.setBackground(Color.WHITE);
        checkoutPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 220, 212)),
            new EmptyBorder(12, 12, 12, 12)
        ));

        // Checkout Title & Cashier Info
        JPanel checkoutHeader = new JPanel(new BorderLayout());
        checkoutHeader.setOpaque(false);
        JLabel lblCartTitle = new JLabel("🛒 Current Order");
        lblCartTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblCartTitle.setForeground(new Color(44, 29, 17));

        JLabel lblCashier = new JLabel("Cashier: " + currentUser.getFullName());
        lblCashier.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblCashier.setForeground(Color.GRAY);

        checkoutHeader.add(lblCartTitle, BorderLayout.WEST);
        checkoutHeader.add(lblCashier, BorderLayout.EAST);

        // Customer Inputs
        JPanel customerPanel = new JPanel(new GridLayout(2, 2, 8, 6));
        customerPanel.setOpaque(false);
        customerPanel.setBorder(new TitledBorder(BorderFactory.createLineBorder(new Color(230, 225, 220)), "Customer Details"));

        customerPanel.add(new JLabel("Customer Name:"));
        txtCustomerName = new JTextField("Walk-in Customer");
        customerPanel.add(txtCustomerName);

        customerPanel.add(new JLabel("Phone Number:"));
        txtCustomerPhone = new JTextField();
        customerPanel.add(txtCustomerPhone);

        JPanel topCartContainer = new JPanel(new BorderLayout(0, 8));
        topCartContainer.setOpaque(false);
        topCartContainer.add(checkoutHeader, BorderLayout.NORTH);
        topCartContainer.add(customerPanel, BorderLayout.SOUTH);
        checkoutPanel.add(topCartContainer, BorderLayout.NORTH);

        // Cart Table
        String[] columns = {"Item", "Price", "Qty", "Total", "Action"};
        cartTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        cartTable = new JTable(cartTableModel);
        cartTable.setRowHeight(28);
        cartTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cartTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        cartTable.getTableHeader().setBackground(new Color(245, 240, 235));

        // Column widths
        cartTable.getColumnModel().getColumn(0).setPreferredWidth(140);
        cartTable.getColumnModel().getColumn(1).setPreferredWidth(55);
        cartTable.getColumnModel().getColumn(2).setPreferredWidth(45);
        cartTable.getColumnModel().getColumn(3).setPreferredWidth(60);
        cartTable.getColumnModel().getColumn(4).setPreferredWidth(60);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        cartTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        cartTable.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);
        cartTable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);

        JScrollPane cartScrollPane = new JScrollPane(cartTable);
        cartScrollPane.setBorder(BorderFactory.createLineBorder(new Color(235, 230, 225)));

        // Cart Item Adjust Buttons Panel (+ / - / Remove)
        JPanel cartControlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 4));
        cartControlPanel.setOpaque(false);

        JButton btnIncrease = new JButton("+");
        btnIncrease.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnIncrease.addActionListener(e -> modifySelectedItemQty(1));

        JButton btnDecrease = new JButton("-");
        btnDecrease.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnDecrease.addActionListener(e -> modifySelectedItemQty(-1));

        JButton btnRemoveItem = new JButton("Remove");
        btnRemoveItem.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btnRemoveItem.setForeground(Color.RED);
        btnRemoveItem.addActionListener(e -> removeSelectedItem());

        cartControlPanel.add(new JLabel("Selected Item: "));
        cartControlPanel.add(btnDecrease);
        cartControlPanel.add(btnIncrease);
        cartControlPanel.add(btnRemoveItem);

        JPanel cartTableContainer = new JPanel(new BorderLayout());
        cartTableContainer.setOpaque(false);
        cartTableContainer.add(cartScrollPane, BorderLayout.CENTER);
        cartTableContainer.add(cartControlPanel, BorderLayout.SOUTH);

        checkoutPanel.add(cartTableContainer, BorderLayout.CENTER);

        // Bill Summary & Payment Section
        JPanel bottomCheckoutPanel = new JPanel();
        bottomCheckoutPanel.setLayout(new BoxLayout(bottomCheckoutPanel, BoxLayout.Y_AXIS));
        bottomCheckoutPanel.setOpaque(false);
        bottomCheckoutPanel.setBorder(new EmptyBorder(8, 0, 0, 0));

        // Calculations Grid
        JPanel calcGrid = new JPanel(new GridLayout(4, 2, 6, 4));
        calcGrid.setOpaque(false);

        calcGrid.add(new JLabel("Subtotal:"));
        lblSubtotal = new JLabel("Rs. 0.00", SwingConstants.RIGHT);
        lblSubtotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        calcGrid.add(lblSubtotal);

        calcGrid.add(new JLabel("Tax (5%):"));
        lblTax = new JLabel("Rs. 0.00", SwingConstants.RIGHT);
        lblTax.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        calcGrid.add(lblTax);

        calcGrid.add(new JLabel("Discount (Rs.):"));
        txtDiscount = new JTextField("0.00");
        txtDiscount.setHorizontalAlignment(JTextField.RIGHT);
        txtDiscount.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { recalculateTotals(); }
            public void removeUpdate(DocumentEvent e) { recalculateTotals(); }
            public void changedUpdate(DocumentEvent e) { recalculateTotals(); }
        });
        calcGrid.add(txtDiscount);

        calcGrid.add(new JLabel("GRAND TOTAL:"));
        lblGrandTotal = new JLabel("Rs. 0.00", SwingConstants.RIGHT);
        lblGrandTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblGrandTotal.setForeground(new Color(176, 75, 20));
        calcGrid.add(lblGrandTotal);

        // Payment Options
        JPanel paymentGrid = new JPanel(new GridLayout(3, 2, 6, 6));
        paymentGrid.setOpaque(false);
        paymentGrid.setBorder(new TitledBorder(BorderFactory.createLineBorder(new Color(230, 225, 220)), "Payment"));

        paymentGrid.add(new JLabel("Payment Method:"));
        cmbPaymentType = new JComboBox<>(new String[]{"CASH", "CARD", "ONLINE"});
        paymentGrid.add(cmbPaymentType);

        paymentGrid.add(new JLabel("Cash Received (Rs.):"));
        txtAmountPaid = new JTextField("0.00");
        txtAmountPaid.setHorizontalAlignment(JTextField.RIGHT);
        txtAmountPaid.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { calculateChange(); }
            public void removeUpdate(DocumentEvent e) { calculateChange(); }
            public void changedUpdate(DocumentEvent e) { calculateChange(); }
        });
        paymentGrid.add(txtAmountPaid);

        paymentGrid.add(new JLabel("Change Due (Rs.):"));
        lblChangeDue = new JLabel("Rs. 0.00", SwingConstants.RIGHT);
        lblChangeDue.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblChangeDue.setForeground(new Color(40, 130, 40));
        paymentGrid.add(lblChangeDue);

        // Action Buttons
        JPanel actionButtonsPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        actionButtonsPanel.setOpaque(false);
        actionButtonsPanel.setBorder(new EmptyBorder(8, 0, 0, 0));

        btnClearCart = new JButton("Clear Order");
        btnClearCart.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnClearCart.setBackground(new Color(240, 235, 230));
        btnClearCart.addActionListener(e -> clearCart());

        btnPlaceOrder = new JButton("Place Order & Pay");
        btnPlaceOrder.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnPlaceOrder.setBackground(new Color(92, 58, 33));
        btnPlaceOrder.setForeground(Color.WHITE);
        btnPlaceOrder.setFocusPainted(false);
        btnPlaceOrder.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnPlaceOrder.addActionListener(e -> processCheckout());

        actionButtonsPanel.add(btnClearCart);
        actionButtonsPanel.add(btnPlaceOrder);

        bottomCheckoutPanel.add(calcGrid);
        bottomCheckoutPanel.add(Box.createVerticalStrut(6));
        bottomCheckoutPanel.add(paymentGrid);
        bottomCheckoutPanel.add(Box.createVerticalStrut(6));
        bottomCheckoutPanel.add(actionButtonsPanel);

        checkoutPanel.add(bottomCheckoutPanel, BorderLayout.SOUTH);

        // Add Catalog and Checkout to Main POS Panel
        add(catalogPanel, BorderLayout.CENTER);
        add(checkoutPanel, BorderLayout.EAST);
    }

    private void loadCategories() {
        categoryTabsPanel.removeAll();

        JButton btnAll = createCategoryFilterButton("All Items", 0);
        categoryTabsPanel.add(btnAll);

        try {
            List<Category> categories = categoryDAO.getAllCategories();
            for (Category cat : categories) {
                JButton btnCat = createCategoryFilterButton(cat.getName(), cat.getId());
                categoryTabsPanel.add(btnCat);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        categoryTabsPanel.revalidate();
        categoryTabsPanel.repaint();
    }

    private JButton createCategoryFilterButton(String text, int categoryId) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        if (this.selectedCategoryId == categoryId) {
            btn.setBackground(new Color(92, 58, 33));
            btn.setForeground(Color.WHITE);
        } else {
            btn.setBackground(Color.WHITE);
            btn.setForeground(new Color(70, 70, 70));
        }

        btn.addActionListener(e -> {
            this.selectedCategoryId = categoryId;
            loadCategories(); // refresh active button colors
            filterProducts();
        });

        return btn;
    }

    public void refreshProducts() {
        loadCategories();
        filterProducts();
    }

    private void filterProducts() {
        String keyword = txtSearch.getText().trim();
        loadProducts(selectedCategoryId, keyword);
    }

    private void loadProducts(int categoryId, String keyword) {
        productGridPanel.removeAll();
        try {
            if (keyword.isEmpty()) {
                currentProductList = productDAO.getProductsByCategory(categoryId);
            } else {
                currentProductList = productDAO.searchProducts(keyword, categoryId);
            }

            for (Product p : currentProductList) {
                ProductCard card = new ProductCard(p, this::addToCart);
                productGridPanel.add(card);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Failed to load products: " + ex.getMessage());
        }

        productGridPanel.revalidate();
        productGridPanel.repaint();
    }

    private void addToCart(Product product) {
        // Check if product is already in cart
        for (OrderItem item : cartItems) {
            if (item.getProductId() == product.getId()) {
                if (item.getQuantity() + 1 > product.getStock()) {
                    ValidationUtils.showWarning("Stock Limit", "Cannot add more. Available stock is: " + product.getStock());
                    return;
                }
                item.setQuantity(item.getQuantity() + 1);
                refreshCartTable();
                return;
            }
        }

        // New item
        OrderItem newItem = new OrderItem(product.getId(), product.getName(), 1, product.getPrice());
        cartItems.add(newItem);
        refreshCartTable();
    }

    private void modifySelectedItemQty(int delta) {
        int row = cartTable.getSelectedRow();
        if (row < 0) return;

        OrderItem item = cartItems.get(row);
        int newQty = item.getQuantity() + delta;

        // Check stock
        Product p = findProductById(item.getProductId());
        if (p != null && newQty > p.getStock()) {
            ValidationUtils.showWarning("Stock Limit", "Maximum available stock is: " + p.getStock());
            return;
        }

        if (newQty <= 0) {
            cartItems.remove(row);
        } else {
            item.setQuantity(newQty);
        }
        refreshCartTable();
    }

    private void removeSelectedItem() {
        int row = cartTable.getSelectedRow();
        if (row >= 0) {
            cartItems.remove(row);
            refreshCartTable();
        }
    }

    private Product findProductById(int productId) {
        for (Product p : currentProductList) {
            if (p.getId() == productId) return p;
        }
        return null;
    }

    private void clearCart() {
        cartItems.clear();
        txtDiscount.setText("0.00");
        txtAmountPaid.setText("0.00");
        txtCustomerName.setText("Walk-in Customer");
        txtCustomerPhone.setText("");
        refreshCartTable();
    }

    private void refreshCartTable() {
        cartTableModel.setRowCount(0);
        for (OrderItem item : cartItems) {
            cartTableModel.addRow(new Object[]{
                item.getProductName(),
                String.format("Rs. %.2f", item.getUnitPrice()),
                item.getQuantity(),
                String.format("Rs. %.2f", item.getSubtotal()),
                "✕"
            });
        }
        recalculateTotals();
    }

    private void recalculateTotals() {
        double subtotal = 0.0;
        for (OrderItem item : cartItems) {
            subtotal += item.getSubtotal();
        }

        double tax = subtotal * TAX_RATE;
        double discount = 0.0;

        try {
            discount = Double.parseDouble(txtDiscount.getText().trim());
        } catch (NumberFormatException ignored) {}

        double grandTotal = Math.max(0, subtotal + tax - discount);

        lblSubtotal.setText(String.format("Rs. %.2f", subtotal));
        lblTax.setText(String.format("Rs. %.2f", tax));
        lblGrandTotal.setText(String.format("Rs. %.2f", grandTotal));

        calculateChange();
    }

    private void calculateChange() {
        double grandTotal = 0.0;
        try {
            String gtStr = lblGrandTotal.getText().replace("Rs.", "").trim();
            grandTotal = Double.parseDouble(gtStr);
        } catch (NumberFormatException ignored) {}

        double amountPaid = 0.0;
        try {
            amountPaid = Double.parseDouble(txtAmountPaid.getText().trim());
        } catch (NumberFormatException ignored) {}

        double change = amountPaid - grandTotal;
        lblChangeDue.setText(String.format("Rs. %.2f", Math.max(0, change)));
    }

    private void processCheckout() {
        if (cartItems.isEmpty()) {
            ValidationUtils.showWarning("Empty Cart", "Please add at least one product to the order.");
            return;
        }

        double subtotal = 0.0;
        for (OrderItem item : cartItems) {
            subtotal += item.getSubtotal();
        }
        double tax = subtotal * TAX_RATE;
        double discount = 0.0;
        try {
            discount = Double.parseDouble(txtDiscount.getText().trim());
        } catch (NumberFormatException ignored) {}
        double grandTotal = Math.max(0, subtotal + tax - discount);

        String paymentType = (String) cmbPaymentType.getSelectedItem();
        double amountPaid = grandTotal;

        if ("CASH".equalsIgnoreCase(paymentType)) {
            try {
                amountPaid = Double.parseDouble(txtAmountPaid.getText().trim());
            } catch (NumberFormatException e) {
                ValidationUtils.showWarning("Payment Validation", "Please enter a valid cash amount.");
                txtAmountPaid.requestFocus();
                return;
            }

            if (amountPaid < grandTotal) {
                ValidationUtils.showWarning("Insufficient Payment", 
                    String.format("Amount paid (Rs. %.2f) is less than the Grand Total (Rs. %.2f).", amountPaid, grandTotal));
                txtAmountPaid.requestFocus();
                return;
            }
        }

        // Generate Unique Order Number
        String orderNumber = "ORD-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
        String customerName = txtCustomerName.getText().trim();
        if (customerName.isEmpty()) customerName = "Walk-in Customer";
        String customerPhone = txtCustomerPhone.getText().trim();

        Order order = new Order();
        order.setOrderNumber(orderNumber);
        order.setCustomerName(customerName);
        order.setCustomerPhone(customerPhone);
        order.setUserId(currentUser.getId());
        order.setUserName(currentUser.getFullName());
        order.setSubtotal(subtotal);
        order.setTaxAmount(tax);
        order.setDiscountAmount(discount);
        order.setNetAmount(grandTotal);
        order.setPaymentType(paymentType);
        order.setPaymentStatus("COMPLETED");
        order.setItems(new ArrayList<>(cartItems));

        try {
            boolean success = orderDAO.saveOrder(order);
            if (success) {
                double changeDue = Math.max(0, amountPaid - grandTotal);
                
                // Show Printable Receipt Dialog
                ReceiptDialog receipt = new ReceiptDialog(parentFrame, order, amountPaid, changeDue);
                receipt.setVisible(true);

                // Reset cart & refresh product catalog stock counts
                clearCart();
                filterProducts();
            } else {
                ValidationUtils.showError("Transaction Error", "Failed to save order. Please check inventory stock.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Order Failed", "Error processing order transaction:\n" + ex.getMessage());
        }
    }
}
