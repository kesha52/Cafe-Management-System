package com.nibm.cafemanagement.dao;

import com.nibm.cafemanagement.config.DBConnection;
import com.nibm.cafemanagement.model.Order;
import com.nibm.cafemanagement.model.OrderItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderDAO {

    /**
     * Saves order header and items in a single database transaction.
     */
    public boolean saveOrder(Order order) throws SQLException {
        Connection conn = DBConnection.getInstance().getConnection();
        boolean originalAutoCommit = conn.getAutoCommit();
        
        String insertOrderSql = "INSERT INTO orders (order_number, customer_name, customer_phone, user_id, " +
                "subtotal, tax_amount, discount_amount, net_amount, payment_type, payment_status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        String insertItemSql = "INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";
        String updateStockSql = "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?";

        try {
            conn.setAutoCommit(false);

            // 1. Insert Order Header
            int orderId = -1;
            try (PreparedStatement pstmt = conn.prepareStatement(insertOrderSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, order.getOrderNumber());
                pstmt.setString(2, order.getCustomerName());
                pstmt.setString(3, order.getCustomerPhone());
                pstmt.setInt(4, order.getUserId());
                pstmt.setDouble(5, order.getSubtotal());
                pstmt.setDouble(6, order.getTaxAmount());
                pstmt.setDouble(7, order.getDiscountAmount());
                pstmt.setDouble(8, order.getNetAmount());
                pstmt.setString(9, order.getPaymentType());
                pstmt.setString(10, order.getPaymentStatus());
                
                int affected = pstmt.executeUpdate();
                if (affected == 0) {
                    conn.rollback();
                    return false;
                }
                
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        orderId = rs.getInt(1);
                        order.setId(orderId);
                    }
                }
            }

            if (orderId <= 0) {
                conn.rollback();
                return false;
            }

            // 2. Insert Order Items & Update Product Stock
            try (PreparedStatement itemPstmt = conn.prepareStatement(insertItemSql);
                 PreparedStatement stockPstmt = conn.prepareStatement(updateStockSql)) {
                
                for (OrderItem item : order.getItems()) {
                    itemPstmt.setInt(1, orderId);
                    itemPstmt.setInt(2, item.getProductId());
                    itemPstmt.setInt(3, item.getQuantity());
                    itemPstmt.setDouble(4, item.getUnitPrice());
                    itemPstmt.setDouble(5, item.getSubtotal());
                    itemPstmt.executeUpdate();

                    // Deduct Stock
                    stockPstmt.setInt(1, item.getQuantity());
                    stockPstmt.setInt(2, item.getProductId());
                    stockPstmt.setInt(3, item.getQuantity());
                    int stockUpdated = stockPstmt.executeUpdate();
                    
                    if (stockUpdated == 0) {
                        conn.rollback();
                        throw new SQLException("Insufficient stock for product ID: " + item.getProductId());
                    }
                }
            }

            // Commit Transaction
            conn.commit();
            return true;
        } catch (SQLException ex) {
            conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(originalAutoCommit);
        }
    }

    public List<Order> getAllOrders() throws SQLException {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT o.*, u.full_name AS user_name FROM orders o " +
                     "JOIN users u ON o.user_id = u.id " +
                     "ORDER BY o.created_at DESC";
        Connection conn = DBConnection.getInstance().getConnection();
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(extractOrderFromResultSet(rs));
            }
        }
        return list;
    }

    public List<OrderItem> getOrderItems(int orderId) throws SQLException {
        List<OrderItem> list = new ArrayList<>();
        String sql = "SELECT oi.*, p.name AS product_name FROM order_items oi " +
                     "JOIN products p ON oi.product_id = p.id " +
                     "WHERE oi.order_id = ?";
        Connection conn = DBConnection.getInstance().getConnection();
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, orderId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new OrderItem(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getInt("product_id"),
                        rs.getString("product_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("unit_price"),
                        rs.getDouble("subtotal")
                    ));
                }
            }
        }
        return list;
    }

    public Map<String, Object> getDashboardStats() throws SQLException {
        Map<String, Object> stats = new HashMap<>();
        Connection conn = DBConnection.getInstance().getConnection();

        // Today's Total Sales Revenue
        String todaySql = "SELECT COALESCE(SUM(net_amount), 0) AS today_sales, COUNT(*) AS today_orders " +
                          "FROM orders WHERE DATE(created_at) = CURRENT_DATE()";
        try (PreparedStatement pstmt = conn.prepareStatement(todaySql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                stats.put("todaySales", rs.getDouble("today_sales"));
                stats.put("todayOrders", rs.getInt("today_orders"));
            }
        }

        // Total Lifetime Revenue & Total Orders
        String totalSql = "SELECT COALESCE(SUM(net_amount), 0) AS total_sales, COUNT(*) AS total_orders FROM orders";
        try (PreparedStatement pstmt = conn.prepareStatement(totalSql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                stats.put("totalSales", rs.getDouble("total_sales"));
                stats.put("totalOrders", rs.getInt("total_orders"));
            }
        }

        // Low Stock Product Count (Stock <= 10)
        String lowStockSql = "SELECT COUNT(*) AS low_stock_count FROM products WHERE stock <= 10";
        try (PreparedStatement pstmt = conn.prepareStatement(lowStockSql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                stats.put("lowStockCount", rs.getInt("low_stock_count"));
            }
        }

        // Total Products Count
        String totalProdSql = "SELECT COUNT(*) AS total_products FROM products";
        try (PreparedStatement pstmt = conn.prepareStatement(totalProdSql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                stats.put("totalProducts", rs.getInt("total_products"));
            }
        }

        return stats;
    }

    private Order extractOrderFromResultSet(ResultSet rs) throws SQLException {
        return new Order(
            rs.getInt("id"),
            rs.getString("order_number"),
            rs.getString("customer_name"),
            rs.getString("customer_phone"),
            rs.getInt("user_id"),
            rs.getString("user_name"),
            rs.getDouble("subtotal"),
            rs.getDouble("tax_amount"),
            rs.getDouble("discount_amount"),
            rs.getDouble("net_amount"),
            rs.getString("payment_type"),
            rs.getString("payment_status"),
            rs.getTimestamp("created_at")
        );
    }
}
