package com.nibm.cafemanagement.ui.components;

import com.nibm.cafemanagement.model.Product;
import com.nibm.cafemanagement.util.ImageUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

public class ProductCard extends JPanel {

    private final Product product;
    private final Consumer<Product> onAddToCart;
    private boolean isHovered = false;

    public ProductCard(Product product, Consumer<Product> onAddToCart) {
        this.product = product;
        this.onAddToCart = onAddToCart;

        setPreferredSize(new Dimension(175, 230));
        setLayout(new BorderLayout(0, 5));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setOpaque(false);

        initComponents();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (product.getStock() > 0) {
                    onAddToCart.accept(product);
                } else {
                    JOptionPane.showMessageDialog(null, 
                        "Item '" + product.getName() + "' is currently out of stock.", 
                        "Out of Stock", JOptionPane.WARNING_MESSAGE);
                }
            }
        });
    }

    private void initComponents() {
        // Top: Product Image
        JLabel lblImage = new JLabel();
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon icon = ImageUtils.getProductIcon(product.getImagePath(), 165, 120, product.getName());
        lblImage.setIcon(icon);
        lblImage.setPreferredSize(new Dimension(165, 120));

        // Center / Info Panel
        JPanel infoPanel = new JPanel();
        infoPanel.setOpaque(false);
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(new EmptyBorder(4, 10, 8, 10));

        JLabel lblName = new JLabel(product.getName());
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblName.setForeground(new Color(44, 29, 17));
        lblName.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Price and Stock row
        JPanel priceRow = new JPanel(new BorderLayout());
        priceRow.setOpaque(false);
        priceRow.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblPrice = new JLabel(String.format("Rs. %.2f", product.getPrice()));
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPrice.setForeground(new Color(176, 75, 20));

        JLabel lblStock = new JLabel(product.getStock() > 0 ? product.getStock() + " left" : "Out of Stock");
        lblStock.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblStock.setForeground(product.getStock() > 0 ? (product.getStock() <= 5 ? Color.RED : new Color(80, 140, 80)) : Color.RED);

        priceRow.add(lblPrice, BorderLayout.WEST);
        priceRow.add(lblStock, BorderLayout.EAST);

        // "Add +" button
        JButton btnAdd = new JButton(product.getStock() > 0 ? "Add +" : "Unavailable");
        btnAdd.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnAdd.setBackground(product.getStock() > 0 ? new Color(92, 58, 33) : Color.LIGHT_GRAY);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFocusPainted(false);
        btnAdd.setEnabled(product.getStock() > 0);
        btnAdd.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnAdd.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        btnAdd.addActionListener(e -> {
            if (product.getStock() > 0) {
                onAddToCart.accept(product);
            }
        });

        infoPanel.add(lblName);
        infoPanel.add(Box.createVerticalStrut(3));
        infoPanel.add(priceRow);
        infoPanel.add(Box.createVerticalStrut(6));
        infoPanel.add(btnAdd);

        add(lblImage, BorderLayout.NORTH);
        add(infoPanel, BorderLayout.CENTER);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Card Background
        g2.setColor(Color.WHITE);
        g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);

        // Border: highlight when hovered
        if (isHovered) {
            g2.setColor(new Color(176, 75, 20));
            g2.setStroke(new BasicStroke(2f));
        } else {
            g2.setColor(new Color(225, 220, 215));
            g2.setStroke(new BasicStroke(1f));
        }
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);

        g2.dispose();
        super.paintComponent(g);
    }
}
