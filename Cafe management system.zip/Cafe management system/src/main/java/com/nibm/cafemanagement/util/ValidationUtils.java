package com.nibm.cafemanagement.util;

import javax.swing.JOptionPane;

public class ValidationUtils {

    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    public static boolean isPositiveNumber(String str) {
        if (isEmpty(str)) return false;
        try {
            double val = Double.parseDouble(str.trim());
            return val >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean isInteger(String str) {
        if (isEmpty(str)) return false;
        try {
            int val = Integer.parseInt(str.trim());
            return val >= 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean validateProductInput(String name, String priceStr, String stockStr, String categoryStr) {
        if (isEmpty(name)) {
            showWarning("Validation Error", "Product Name cannot be empty.");
            return false;
        }
        if (isEmpty(categoryStr)) {
            showWarning("Validation Error", "Please select a valid Category.");
            return false;
        }
        if (!isPositiveNumber(priceStr)) {
            showWarning("Validation Error", "Please enter a valid positive number for Product Price.");
            return false;
        }
        if (!isInteger(stockStr)) {
            showWarning("Validation Error", "Please enter a valid integer for Stock quantity.");
            return false;
        }
        return true;
    }

    public static void showWarning(String title, String message) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.WARNING_MESSAGE);
    }

    public static void showInfo(String title, String message) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showError(String title, String message) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.ERROR_MESSAGE);
    }
}
