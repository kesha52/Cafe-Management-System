package com.nibm.cafemanagement.util;

import com.nibm.cafemanagement.config.DBConnection;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.*;
import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

public class JasperReportManager {

    private static final String REPORT_JRXML_PATH = "/reports/sales_report.jrxml";

    public static void showSalesReport(String startDate, String endDate) {
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            if (conn == null || conn.isClosed()) {
                ValidationUtils.showError("Database Error", "No active database connection available for report.");
                return;
            }

            InputStream reportStream = JasperReportManager.class.getResourceAsStream(REPORT_JRXML_PATH);
            if (reportStream == null) {
                // Try relative file path
                File file = new File("src/main/resources" + REPORT_JRXML_PATH);
                if (!file.exists()) {
                    ValidationUtils.showError("Report Error", "Jasper report template not found: " + REPORT_JRXML_PATH);
                    return;
                }
                reportStream = new java.io.FileInputStream(file);
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            Map<String, Object> params = new HashMap<>();
            params.put("StartDate", startDate);
            params.put("EndDate", endDate);
            params.put("ReportTitle", "Aura Artisan Cafe Sales & Decision Report");

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, conn);

            if (jasperPrint.getPages().isEmpty()) {
                ValidationUtils.showWarning("Report Notice", "No sales records found for the selected date range: " + startDate + " to " + endDate);
                return;
            }

            // Display in JasperViewer
            SwingUtilities.invokeLater(() -> {
                JasperViewer viewer = new JasperViewer(jasperPrint, false);
                viewer.setTitle("Aura Artisan Cafe - Sales Analytics & Decision Report");
                viewer.setVisible(true);
            });

        } catch (Exception ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Jasper Report Error", "Failed to generate Jasper Report:\n" + ex.getMessage());
        }
    }

    public static boolean exportSalesReportToPdf(String startDate, String endDate, File destinationPdfFile) {
        try {
            Connection conn = DBConnection.getInstance().getConnection();
            if (conn == null || conn.isClosed()) {
                ValidationUtils.showError("Database Error", "No active database connection available.");
                return false;
            }

            InputStream reportStream = JasperReportManager.class.getResourceAsStream(REPORT_JRXML_PATH);
            if (reportStream == null) {
                File file = new File("src/main/resources" + REPORT_JRXML_PATH);
                if (file.exists()) {
                    reportStream = new java.io.FileInputStream(file);
                }
            }

            if (reportStream == null) {
                ValidationUtils.showError("Report Error", "Jasper report template missing.");
                return false;
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            Map<String, Object> params = new HashMap<>();
            params.put("StartDate", startDate);
            params.put("EndDate", endDate);
            params.put("ReportTitle", "Aura Artisan Cafe Sales & Decision Report");

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, params, conn);
            JasperExportManager.exportReportToPdfFile(jasperPrint, destinationPdfFile.getAbsolutePath());
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            ValidationUtils.showError("PDF Export Error", "Failed to export report to PDF:\n" + ex.getMessage());
            return false;
        }
    }
}
