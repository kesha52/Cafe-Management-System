package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.ReportDAO;
import com.nibm.cafemanagement.model.SalesReportItem;
import com.nibm.cafemanagement.util.JasperReportManager;
import com.nibm.cafemanagement.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

public class SalesReportsPanel extends JPanel {

    private final ReportDAO reportDAO = new ReportDAO();

    private JTextField txtStartDate;
    private JTextField txtEndDate;
    private JTable reportTable;
    private DefaultTableModel tableModel;

    private JLabel lblTotalRevenue;
    private JLabel lblTotalItems;
    private JLabel lblTotalRecords;

    public SalesReportsPanel() {
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(248, 246, 242));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        initComponents();
        loadReportData();
    }

    private void initComponents() {
        // TOP CONTROL BAR
        JPanel topBar = new JPanel(new BorderLayout(10, 10));
        topBar.setOpaque(false);

        // Header Title
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        JLabel lblTitle = new JLabel("📊 Sales Analytics & Jasper Reports");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(44, 29, 17));
        JLabel lblDesc = new JLabel("Multi-table decision making report (Orders, Items, Products, Categories, Users)");
        lblDesc.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblDesc.setForeground(Color.GRAY);
        titlePanel.add(lblTitle, BorderLayout.NORTH);
        titlePanel.add(lblDesc, BorderLayout.SOUTH);

        // Date Filter & Action Buttons Bar
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        filterBar.setOpaque(false);

        // Defaults: Last 30 days to today
        LocalDate today = LocalDate.now();
        LocalDate lastMonth = today.minusDays(30);

        filterBar.add(new JLabel("From (YYYY-MM-DD):"));
        txtStartDate = new JTextField(lastMonth.toString(), 9);
        filterBar.add(txtStartDate);

        filterBar.add(new JLabel("To (YYYY-MM-DD):"));
        txtEndDate = new JTextField(today.toString(), 9);
        filterBar.add(txtEndDate);

        JButton btnFilter = new JButton("Filter");
        btnFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnFilter.addActionListener(e -> loadReportData());
        filterBar.add(btnFilter);

        JButton btnJasper = new JButton("⚡ Open Jasper Report");
        btnJasper.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnJasper.setBackground(new Color(92, 58, 33));
        btnJasper.setForeground(Color.WHITE);
        btnJasper.setFocusPainted(false);
        btnJasper.addActionListener(e -> generateJasperReport());
        filterBar.add(btnJasper);

        JButton btnPdf = new JButton("📄 Export to PDF");
        btnPdf.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnPdf.setBackground(new Color(180, 100, 30));
        btnPdf.setForeground(Color.WHITE);
        btnPdf.setFocusPainted(false);
        btnPdf.addActionListener(e -> exportPdfReport());
        filterBar.add(btnPdf);

        topBar.add(titlePanel, BorderLayout.WEST);
        topBar.add(filterBar, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // CENTER: TABLE OF REPORT ITEMS
        String[] cols = {"Order #", "Date", "Customer", "Category", "Product", "Qty", "Unit Price (Rs.)", "Total (Rs.)", "Cashier"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };

        reportTable = new JTable(tableModel);
        reportTable.setRowHeight(28);
        reportTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reportTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        reportTable.getTableHeader().setBackground(new Color(245, 240, 235));

        DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
        centerRender.setHorizontalAlignment(JLabel.CENTER);
        reportTable.getColumnModel().getColumn(0).setCellRenderer(centerRender);
        reportTable.getColumnModel().getColumn(1).setCellRenderer(centerRender);
        reportTable.getColumnModel().getColumn(5).setCellRenderer(centerRender);

        DefaultTableCellRenderer rightRender = new DefaultTableCellRenderer();
        rightRender.setHorizontalAlignment(JLabel.RIGHT);
        reportTable.getColumnModel().getColumn(6).setCellRenderer(rightRender);
        reportTable.getColumnModel().getColumn(7).setCellRenderer(rightRender);

        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(225, 220, 215)));
        add(scrollPane, BorderLayout.CENTER);

        // BOTTOM: METRICS SUMMARY CARDS
        JPanel summaryPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        summaryPanel.setOpaque(false);
        summaryPanel.setPreferredSize(new Dimension(0, 75));

        summaryPanel.add(createMetricCard("Total Revenue", lblTotalRevenue = new JLabel("Rs. 0.00"), new Color(46, 125, 50)));
        summaryPanel.add(createMetricCard("Total Items Sold", lblTotalItems = new JLabel("0 units"), new Color(21, 101, 192)));
        summaryPanel.add(createMetricCard("Total Transactions", lblTotalRecords = new JLabel("0 lines"), new Color(156, 39, 176)));

        add(summaryPanel, BorderLayout.SOUTH);
    }

    private JPanel createMetricCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 5, 0, 0, accentColor),
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 225, 220)),
                new EmptyBorder(10, 15, 10, 15)
            )
        ));

        JLabel lblT = new JLabel(title);
        lblT.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblT.setForeground(Color.GRAY);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        valueLabel.setForeground(new Color(44, 29, 17));

        card.add(lblT, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private void loadReportData() {
        String sDateStr = txtStartDate.getText().trim();
        String eDateStr = txtEndDate.getText().trim();

        Date startDate;
        Date endDate;
        try {
            startDate = Date.valueOf(sDateStr);
            endDate = Date.valueOf(eDateStr);
        } catch (IllegalArgumentException e) {
            ValidationUtils.showWarning("Invalid Date", "Please enter valid dates in format YYYY-MM-DD.");
            return;
        }

        tableModel.setRowCount(0);
        double totalRev = 0.0;
        int totalQty = 0;

        try {
            List<SalesReportItem> items = reportDAO.getSalesReportData(startDate, endDate);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            for (SalesReportItem it : items) {
                tableModel.addRow(new Object[]{
                    it.getOrderNumber(),
                    sdf.format(it.getOrderDate()),
                    it.getCustomerName(),
                    it.getCategoryName(),
                    it.getProductName(),
                    it.getQuantity(),
                    String.format("%.2f", it.getUnitPrice()),
                    String.format("%.2f", it.getTotalAmount()),
                    it.getCashierName()
                });

                totalRev += it.getTotalAmount();
                totalQty += it.getQuantity();
            }

            lblTotalRevenue.setText(String.format("Rs. %.2f", totalRev));
            lblTotalItems.setText(totalQty + " units");
            lblTotalRecords.setText(items.size() + " line items");

        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Failed to fetch report data: " + ex.getMessage());
        }
    }

    private void generateJasperReport() {
        String sDate = txtStartDate.getText().trim();
        String eDate = txtEndDate.getText().trim();
        JasperReportManager.showSalesReport(sDate, eDate);
    }

    private void exportPdfReport() {
        String sDate = txtStartDate.getText().trim();
        String eDate = txtEndDate.getText().trim();

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save Report as PDF");
        fileChooser.setSelectedFile(new File("Aura_Cafe_Sales_Report_" + sDate + "_to_" + eDate + ".pdf"));
        fileChooser.setFileFilter(new FileNameExtensionFilter("PDF Documents (*.pdf)", "pdf"));

        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            if (!fileToSave.getName().toLowerCase().endsWith(".pdf")) {
                fileToSave = new File(fileToSave.getParentFile(), fileToSave.getName() + ".pdf");
            }

            boolean ok = JasperReportManager.exportSalesReportToPdf(sDate, eDate, fileToSave);
            if (ok) {
                ValidationUtils.showInfo("Export Successful", "Report exported successfully to:\n" + fileToSave.getAbsolutePath());
            }
        }
    }
}
