package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.model.Order;
import com.nibm.cafemanagement.model.OrderItem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.print.PrinterException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ReceiptDialog extends JDialog {

    private final JTextArea txtReceipt;

    public ReceiptDialog(Frame parent, Order order, double amountPaid, double changeDue) {
        super(parent, "Transaction Receipt - " + order.getOrderNumber(), true);
        setSize(420, 580);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        txtReceipt = new JTextArea();
        txtReceipt.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtReceipt.setEditable(false);
        txtReceipt.setMargin(new Insets(15, 15, 15, 15));
        txtReceipt.setBackground(new Color(254, 253, 250));

        populateReceiptText(order, amountPaid, changeDue);

        JScrollPane scrollPane = new JScrollPane(txtReceipt);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom Actions Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(new EmptyBorder(5, 10, 5, 10));

        JButton btnPrint = new JButton("Print Receipt");
        btnPrint.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnPrint.setBackground(new Color(92, 58, 33));
        btnPrint.setForeground(Color.WHITE);
        btnPrint.setFocusPainted(false);
        btnPrint.addActionListener(e -> {
            try {
                txtReceipt.print();
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Print failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnClose = new JButton("Close");
        btnClose.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnClose.addActionListener(e -> dispose());

        bottomPanel.add(btnPrint);
        bottomPanel.add(btnClose);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void populateReceiptText(Order order, double amountPaid, double changeDue) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = sdf.format(new Date());

        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("         AURA ARTISAN CAFE             \n");
        sb.append("     Premium Coffee & Fresh Bakery      \n");
        sb.append("         Tel: +94 11 234 5678           \n");
        sb.append("========================================\n");
        sb.append("Order No   : ").append(order.getOrderNumber()).append("\n");
        sb.append("Date       : ").append(formattedDate).append("\n");
        sb.append("Cashier    : ").append(order.getUserName() != null ? order.getUserName() : "Cashier").append("\n");
        sb.append("Customer   : ").append(order.getCustomerName()).append("\n");
        if (order.getCustomerPhone() != null && !order.getCustomerPhone().isEmpty()) {
            sb.append("Phone      : ").append(order.getCustomerPhone()).append("\n");
        }
        sb.append("----------------------------------------\n");
        sb.append(String.format("%-18s %4s %7s %8s\n", "Item", "Qty", "Price", "Total"));
        sb.append("----------------------------------------\n");

        for (OrderItem item : order.getItems()) {
            String name = item.getProductName();
            if (name.length() > 17) {
                name = name.substring(0, 15) + "..";
            }
            sb.append(String.format("%-18s %4d %7.2f %8.2f\n", 
                name, item.getQuantity(), item.getUnitPrice(), item.getSubtotal()));
        }

        sb.append("----------------------------------------\n");
        sb.append(String.format("%-26s Rs. %8.2f\n", "Subtotal:", order.getSubtotal()));
        sb.append(String.format("%-26s Rs. %8.2f\n", "Tax (5%):", order.getTaxAmount()));
        if (order.getDiscountAmount() > 0) {
            sb.append(String.format("%-26s-Rs. %8.2f\n", "Discount:", order.getDiscountAmount()));
        }
        sb.append("========================================\n");
        sb.append(String.format("%-26s Rs. %8.2f\n", "GRAND TOTAL:", order.getNetAmount()));
        sb.append("========================================\n");
        sb.append(String.format("%-26s %11s\n", "Payment Method:", order.getPaymentType()));
        sb.append(String.format("%-26s Rs. %8.2f\n", "Amount Tendered:", amountPaid));
        sb.append(String.format("%-26s Rs. %8.2f\n", "Change Due:", changeDue));
        sb.append("========================================\n");
        sb.append("      Thank you for your visit!         \n");
        sb.append("       Please come back again!          \n");
        sb.append("========================================\n");

        txtReceipt.setText(sb.toString());
    }
}
