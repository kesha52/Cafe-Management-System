package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.OrderDAO;
import com.nibm.cafemanagement.model.Order;
import com.nibm.cafemanagement.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class DashboardPanel extends JPanel {

    private final User currentUser;
    private final Consumer<String> navigationHandler;
    private final OrderDAO orderDAO = new OrderDAO();

    // Metric Labels
    private JLabel lblTodaySales;
    private JLabel lblTodayOrders;
    private JLabel lblTotalSales;
    private JLabel lblLowStock;

    // Table
    private JTable ordersTable;
    private DefaultTableModel ordersTableModel;

    public DashboardPanel(User user, Consumer<String> navigationHandler) {
        this.currentUser = user;
        this.navigationHandler = navigationHandler;

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(248, 246, 242));
        setBorder(new EmptyBorder(15, 20, 15, 20));

        initComponents();
        refreshDashboard();
    }

    private void initComponents() {
        // TOP WELCOME HEADER & QUICK ACTIONS
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setOpaque(false);

        JPanel titleGrp = new JPanel(new BorderLayout(0, 3));
        titleGrp.setOpaque(false);

        JLabel lblWelcome = new JLabel("Welcome back, " + currentUser.getFullName() + "! 👋");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblWelcome.setForeground(new Color(44, 29, 17));

        JLabel lblSub = new JLabel("Aura Artisan Cafe Operations & Sales Performance Overview");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSub.setForeground(Color.GRAY);

        titleGrp.add(lblWelcome, BorderLayout.NORTH);
        titleGrp.add(lblSub, BorderLayout.SOUTH);

        JPanel quickActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        quickActions.setOpaque(false);

        JButton btnNewSale = new JButton("🛒 New Sale (POS)");
        btnNewSale.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnNewSale.setBackground(new Color(92, 58, 33));
        btnNewSale.setForeground(Color.WHITE);
        btnNewSale.setFocusPainted(false);
        btnNewSale.addActionListener(e -> navigationHandler.accept("POS"));

        JButton btnRefresh = new JButton("🔄 Refresh Data");
        btnRefresh.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRefresh.addActionListener(e -> refreshDashboard());

        quickActions.add(btnNewSale);
        quickActions.add(btnRefresh);

        topHeader.add(titleGrp, BorderLayout.WEST);
        topHeader.add(quickActions, BorderLayout.EAST);
        add(topHeader, BorderLayout.NORTH);

        // CENTER CONTAINER
        JPanel centerPanel = new JPanel(new BorderLayout(0, 15));
        centerPanel.setOpaque(false);

        // 1. KPI Cards Row (4 Cards)
        JPanel kpiRow = new JPanel(new GridLayout(1, 4, 15, 0));
        kpiRow.setOpaque(false);
        kpiRow.setPreferredSize(new Dimension(0, 95));

        kpiRow.add(createKpiCard("TODAY'S REVENUE", lblTodaySales = new JLabel("Rs. 0.00"), "📅 Real-time sales", new Color(46, 125, 50)));
        kpiRow.add(createKpiCard("TODAY'S ORDERS", lblTodayOrders = new JLabel("0"), "☕ Customers served", new Color(21, 101, 192)));
        kpiRow.add(createKpiCard("TOTAL REVENUE", lblTotalSales = new JLabel("Rs. 0.00"), "📈 Lifetime sales", new Color(156, 39, 176)));
        kpiRow.add(createKpiCard("LOW STOCK ALERT", lblLowStock = new JLabel("0 items"), "⚠️ Needs restock", new Color(198, 40, 40)));

        centerPanel.add(kpiRow, BorderLayout.NORTH);

        // 2. Recent Transactions Section
        JPanel tableSection = new JPanel(new BorderLayout(0, 8));
        tableSection.setOpaque(false);

        JLabel lblSecTitle = new JLabel("Recent Customer Transactions");
        lblSecTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblSecTitle.setForeground(new Color(44, 29, 17));
        tableSection.add(lblSecTitle, BorderLayout.NORTH);

        String[] cols = {"Order Number", "Date & Time", "Customer", "Subtotal", "Tax", "Net Total (Rs.)", "Payment", "Cashier"};
        ordersTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };

        ordersTable = new JTable(ordersTableModel);
        ordersTable.setRowHeight(30);
        ordersTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        ordersTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        ordersTable.getTableHeader().setBackground(new Color(245, 240, 235));

        DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
        centerRender.setHorizontalAlignment(JLabel.CENTER);
        ordersTable.getColumnModel().getColumn(0).setCellRenderer(centerRender);
        ordersTable.getColumnModel().getColumn(1).setCellRenderer(centerRender);
        ordersTable.getColumnModel().getColumn(6).setCellRenderer(centerRender);

        DefaultTableCellRenderer rightRender = new DefaultTableCellRenderer();
        rightRender.setHorizontalAlignment(JLabel.RIGHT);
        ordersTable.getColumnModel().getColumn(3).setCellRenderer(rightRender);
        ordersTable.getColumnModel().getColumn(4).setCellRenderer(rightRender);
        ordersTable.getColumnModel().getColumn(5).setCellRenderer(rightRender);

        JScrollPane scrollPane = new JScrollPane(ordersTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(225, 220, 215)));
        tableSection.add(scrollPane, BorderLayout.CENTER);

        centerPanel.add(tableSection, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    private JPanel createKpiCard(String title, JLabel valueLabel, String subtitle, Color topBarColor) {
        JPanel card = new JPanel(new BorderLayout(0, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(4, 0, 0, 0, topBarColor),
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 225, 220)),
                new EmptyBorder(12, 16, 12, 16)
            )
        ));

        JLabel lblT = new JLabel(title);
        lblT.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblT.setForeground(Color.GRAY);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valueLabel.setForeground(new Color(44, 29, 17));

        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSub.setForeground(new Color(130, 130, 130));

        card.add(lblT, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(lblSub, BorderLayout.SOUTH);
        return card;
    }

    public void refreshDashboard() {
        try {
            Map<String, Object> stats = orderDAO.getDashboardStats();
            double todaySales = (double) stats.getOrDefault("todaySales", 0.0);
            int todayOrders = (int) stats.getOrDefault("todayOrders", 0);
            double totalSales = (double) stats.getOrDefault("totalSales", 0.0);
            int lowStock = (int) stats.getOrDefault("lowStockCount", 0);

            lblTodaySales.setText(String.format("Rs. %.2f", todaySales));
            lblTodayOrders.setText(String.valueOf(todayOrders));
            lblTotalSales.setText(String.format("Rs. %.2f", totalSales));
            lblLowStock.setText(lowStock + " items");

            // Populate recent orders
            ordersTableModel.setRowCount(0);
            List<Order> orders = orderDAO.getAllOrders();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            int count = 0;
            for (Order o : orders) {
                ordersTableModel.addRow(new Object[]{
                    o.getOrderNumber(),
                    sdf.format(o.getCreatedAt()),
                    o.getCustomerName(),
                    String.format("%.2f", o.getSubtotal()),
                    String.format("%.2f", o.getTaxAmount()),
                    String.format("%.2f", o.getNetAmount()),
                    o.getPaymentType(),
                    o.getUserName()
                });
                count++;
                if (count >= 15) break; // show top 15 recent
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
