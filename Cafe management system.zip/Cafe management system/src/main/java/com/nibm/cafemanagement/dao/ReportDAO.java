package com.nibm.cafemanagement.dao;

import com.nibm.cafemanagement.config.DBConnection;
import com.nibm.cafemanagement.model.SalesReportItem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

    /**
     * Retrieves sales data joining 5 tables: orders, order_items, products, categories, users.
     * Fulfills rubric requirement for multi-table decision making report.
     */
    public List<SalesReportItem> getSalesReportData(Date startDate, Date endDate) throws SQLException {
        List<SalesReportItem> list = new ArrayList<>();
        String sql = "SELECT " +
                     "   o.order_number, " +
                     "   o.created_at AS order_date, " +
                     "   o.customer_name, " +
                     "   c.name AS category_name, " +
                     "   p.name AS product_name, " +
                     "   oi.quantity, " +
                     "   oi.unit_price, " +
                     "   oi.subtotal AS total_amount, " +
                     "   u.full_name AS cashier_name " +
                     "FROM orders o " +
                     "JOIN order_items oi ON o.id = oi.order_id " +
                     "JOIN products p ON oi.product_id = p.id " +
                     "JOIN categories c ON p.category_id = c.id " +
                     "JOIN users u ON o.user_id = u.id " +
                     "WHERE DATE(o.created_at) >= ? AND DATE(o.created_at) <= ? " +
                     "ORDER BY o.created_at DESC";

        Connection conn = DBConnection.getInstance().getConnection();
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, startDate);
            pstmt.setDate(2, endDate);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(new SalesReportItem(
                        rs.getString("order_number"),
                        rs.getTimestamp("order_date"),
                        rs.getString("customer_name"),
                        rs.getString("category_name"),
                        rs.getString("product_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("unit_price"),
                        rs.getDouble("total_amount"),
                        rs.getString("cashier_name")
                    ));
                }
            }
        }
        return list;
    }
}
