package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.CategoryDAO;
import com.nibm.cafemanagement.dao.ProductDAO;
import com.nibm.cafemanagement.model.Category;
import com.nibm.cafemanagement.model.Product;
import com.nibm.cafemanagement.util.ImageUtils;
import com.nibm.cafemanagement.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.sql.SQLException;
import java.util.List;

public class ProductManagementPanel extends JPanel {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    // Table
    private JTable productTable;
    private DefaultTableModel tableModel;
    private List<Product> productList;

    // Form inputs
    private JTextField txtId;
    private JTextField txtName;
    private JComboBox<Category> cmbCategory;
    private JTextField txtPrice;
    private JTextField txtStock;
    private JTextArea txtDescription;
    private JTextField txtImagePath;
    private JLabel lblImagePreview;
    private JButton btnBrowseImage;

    // Actions
    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JTextField txtSearch;

    public ProductManagementPanel() {
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(248, 246, 242));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        initComponents();
        loadCategories();
        loadProductTable();
    }

    private void initComponents() {
        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setOpaque(false);
        JLabel lblHeader = new JLabel("☕ Product & Inventory Management");
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(44, 29, 17));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchPanel.setOpaque(false);
        searchPanel.add(new JLabel("Search Product:"));
        txtSearch = new JTextField(15);
        JButton btnSearch = new JButton("Search");
        btnSearch.addActionListener(e -> searchProducts());
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadProductTable();
        });
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        searchPanel.add(btnRefresh);

        topHeader.add(lblHeader, BorderLayout.WEST);
        topHeader.add(searchPanel, BorderLayout.EAST);
        add(topHeader, BorderLayout.NORTH);

        // Center Split: Left = Input Form with Image Preview, Right = Products Table
        JPanel mainContent = new JPanel(new BorderLayout(15, 0));
        mainContent.setOpaque(false);

        // LEFT FORM PANEL
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setPreferredSize(new Dimension(380, 0));
        formContainer.setBackground(Color.WHITE);
        formContainer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 220, 215)),
            new EmptyBorder(12, 15, 12, 15)
        ));

        JLabel lblFormTitle = new JLabel("Product Details");
        lblFormTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblFormTitle.setForeground(new Color(44, 29, 17));
        lblFormTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        formContainer.add(lblFormTitle);
        formContainer.add(Box.createVerticalStrut(10));

        // Form Fields
        txtId = new JTextField();
        txtId.setEditable(false);
        txtId.setVisible(false);

        txtName = new JTextField();
        cmbCategory = new JComboBox<>();
        txtPrice = new JTextField();
        txtStock = new JTextField();
        txtDescription = new JTextArea(3, 20);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        txtImagePath = new JTextField();

        formContainer.add(createFieldRow("Product Name *:", txtName));
        formContainer.add(createFieldRow("Category *:", cmbCategory));
        formContainer.add(createFieldRow("Price (Rs.) *:", txtPrice));
        formContainer.add(createFieldRow("Stock Qty *:", txtStock));
        
        JScrollPane descScroll = new JScrollPane(txtDescription);
        descScroll.setPreferredSize(new Dimension(240, 60));
        formContainer.add(createFieldRow("Description:", descScroll));

        // Image Selection Row
        JPanel imgSelectPanel = new JPanel(new BorderLayout(5, 0));
        imgSelectPanel.setOpaque(false);
        txtImagePath.setEditable(false);
        btnBrowseImage = new JButton("Browse...");
        btnBrowseImage.addActionListener(e -> chooseProductImage());
        imgSelectPanel.add(txtImagePath, BorderLayout.CENTER);
        imgSelectPanel.add(btnBrowseImage, BorderLayout.EAST);
        formContainer.add(createFieldRow("Product Image:", imgSelectPanel));

        // Image Preview Box
        lblImagePreview = new JLabel();
        lblImagePreview.setHorizontalAlignment(SwingConstants.CENTER);
        lblImagePreview.setPreferredSize(new Dimension(150, 110));
        lblImagePreview.setBorder(BorderFactory.createTitledBorder("Image Preview"));
        lblImagePreview.setAlignmentX(Component.LEFT_ALIGNMENT);
        updateImagePreview("product_images/espresso.png", "Preview");
        formContainer.add(Box.createVerticalStrut(8));
        formContainer.add(lblImagePreview);

        // Buttons (Add, Update, Delete, Clear)
        JPanel btnRow = new JPanel(new GridLayout(2, 2, 8, 8));
        btnRow.setOpaque(false);
        btnRow.setBorder(new EmptyBorder(12, 0, 0, 0));

        btnAdd = new JButton("Add Product");
        btnAdd.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnAdd.setBackground(new Color(92, 58, 33));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFocusPainted(false);
        btnAdd.addActionListener(e -> addProduct());

        btnUpdate = new JButton("Update");
        btnUpdate.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUpdate.setBackground(new Color(180, 100, 30));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.setFocusPainted(false);
        btnUpdate.addActionListener(e -> updateProduct());

        btnDelete = new JButton("Delete");
        btnDelete.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnDelete.setBackground(new Color(180, 40, 40));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.setFocusPainted(false);
        btnDelete.addActionListener(e -> deleteProduct());

        btnClear = new JButton("Clear Form");
        btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnClear.addActionListener(e -> clearForm());

        btnRow.add(btnAdd);
        btnRow.add(btnUpdate);
        btnRow.add(btnDelete);
        btnRow.add(btnClear);

        formContainer.add(Box.createVerticalGlue());
        formContainer.add(btnRow);

        mainContent.add(formContainer, BorderLayout.WEST);

        // RIGHT: PRODUCTS TABLE
        String[] columns = {"ID", "Image", "Name", "Category", "Price (Rs.)", "Stock", "Description"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
            @Override
            public Class<?> getColumnClass(int column) {
                if (column == 1) return ImageIcon.class;
                return Object.class;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setRowHeight(55);
        productTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        productTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        productTable.getTableHeader().setBackground(new Color(245, 240, 235));

        productTable.getColumnModel().getColumn(0).setPreferredWidth(35);
        productTable.getColumnModel().getColumn(1).setPreferredWidth(65);
        productTable.getColumnModel().getColumn(2).setPreferredWidth(140);
        productTable.getColumnModel().getColumn(3).setPreferredWidth(110);
        productTable.getColumnModel().getColumn(4).setPreferredWidth(65);
        productTable.getColumnModel().getColumn(5).setPreferredWidth(55);
        productTable.getColumnModel().getColumn(6).setPreferredWidth(160);

        DefaultTableCellRenderer centerRender = new DefaultTableCellRenderer();
        centerRender.setHorizontalAlignment(JLabel.CENTER);
        productTable.getColumnModel().getColumn(0).setCellRenderer(centerRender);
        productTable.getColumnModel().getColumn(4).setCellRenderer(centerRender);
        productTable.getColumnModel().getColumn(5).setCellRenderer(centerRender);

        productTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && productTable.getSelectedRow() >= 0) {
                populateFormFromSelectedRow();
            }
        });

        JScrollPane tableScroll = new JScrollPane(productTable);
        tableScroll.setBorder(BorderFactory.createLineBorder(new Color(225, 220, 215)));
        mainContent.add(tableScroll, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFieldRow(String label, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(8, 2));
        p.setOpaque(false);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(l, BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    private void chooseProductImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select Product Image");
        chooser.setFileFilter(new FileNameExtensionFilter("Image Files (*.png, *.jpg, *.jpeg)", "png", "jpg", "jpeg"));
        int res = chooser.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File selected = chooser.getSelectedFile();
            txtImagePath.setText(selected.getAbsolutePath());
            updateImagePreview(selected.getAbsolutePath(), txtName.getText().trim());
        }
    }

    private void updateImagePreview(String path, String title) {
        ImageIcon icon = ImageUtils.getProductIcon(path, 130, 85, title);
        lblImagePreview.setIcon(icon);
    }

    private void loadCategories() {
        cmbCategory.removeAllItems();
        try {
            List<Category> categories = categoryDAO.getAllCategories();
            for (Category c : categories) {
                cmbCategory.addItem(c);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadProductTable() {
        tableModel.setRowCount(0);
        try {
            productList = productDAO.getAllProducts();
            for (Product p : productList) {
                ImageIcon thumb = ImageUtils.getProductIcon(p.getImagePath(), 50, 40, p.getName());
                tableModel.addRow(new Object[]{
                    p.getId(),
                    thumb,
                    p.getName(),
                    p.getCategoryName(),
                    String.format("%.2f", p.getPrice()),
                    p.getStock(),
                    p.getDescription()
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Failed to load products: " + ex.getMessage());
        }
    }

    private void searchProducts() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadProductTable();
            return;
        }
        tableModel.setRowCount(0);
        try {
            productList = productDAO.searchProducts(keyword, 0);
            for (Product p : productList) {
                ImageIcon thumb = ImageUtils.getProductIcon(p.getImagePath(), 50, 40, p.getName());
                tableModel.addRow(new Object[]{
                    p.getId(),
                    thumb,
                    p.getName(),
                    p.getCategoryName(),
                    String.format("%.2f", p.getPrice()),
                    p.getStock(),
                    p.getDescription()
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void populateFormFromSelectedRow() {
        int row = productTable.getSelectedRow();
        if (row < 0 || row >= productList.size()) return;

        Product p = productList.get(row);
        txtId.setText(String.valueOf(p.getId()));
        txtName.setText(p.getName());
        txtPrice.setText(String.format("%.2f", p.getPrice()));
        txtStock.setText(String.valueOf(p.getStock()));
        txtDescription.setText(p.getDescription() != null ? p.getDescription() : "");
        txtImagePath.setText(p.getImagePath() != null ? p.getImagePath() : "");

        for (int i = 0; i < cmbCategory.getItemCount(); i++) {
            Category c = cmbCategory.getItemAt(i);
            if (c.getId() == p.getCategoryId()) {
                cmbCategory.setSelectedIndex(i);
                break;
            }
        }

        updateImagePreview(p.getImagePath(), p.getName());
    }

    private void addProduct() {
        String name = txtName.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String stockStr = txtStock.getText().trim();
        Category cat = (Category) cmbCategory.getSelectedItem();

        if (!ValidationUtils.validateProductInput(name, priceStr, stockStr, cat != null ? cat.getName() : null)) {
            return;
        }

        double price = Double.parseDouble(priceStr);
        int stock = Integer.parseInt(stockStr);
        String desc = txtDescription.getText().trim();
        String imagePath = txtImagePath.getText().trim();
        if (imagePath.isEmpty()) {
            imagePath = "product_images/espresso.png";
        }

        Product p = new Product();
        p.setCategoryId(cat.getId());
        p.setName(name);
        p.setDescription(desc);
        p.setPrice(price);
        p.setStock(stock);
        p.setImagePath(imagePath);

        try {
            boolean ok = productDAO.addProduct(p);
            if (ok) {
                ValidationUtils.showInfo("Success", "Product '" + name + "' added successfully!");
                clearForm();
                loadProductTable();
            } else {
                ValidationUtils.showError("Error", "Failed to add product.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Error: " + ex.getMessage());
        }
    }

    private void updateProduct() {
        String idStr = txtId.getText().trim();
        if (idStr.isEmpty()) {
            ValidationUtils.showWarning("Selection Required", "Please select a product from the table to update.");
            return;
        }

        String name = txtName.getText().trim();
        String priceStr = txtPrice.getText().trim();
        String stockStr = txtStock.getText().trim();
        Category cat = (Category) cmbCategory.getSelectedItem();

        if (!ValidationUtils.validateProductInput(name, priceStr, stockStr, cat != null ? cat.getName() : null)) {
            return;
        }

        int id = Integer.parseInt(idStr);
        double price = Double.parseDouble(priceStr);
        int stock = Integer.parseInt(stockStr);
        String desc = txtDescription.getText().trim();
        String imagePath = txtImagePath.getText().trim();

        Product p = new Product();
        p.setId(id);
        p.setCategoryId(cat.getId());
        p.setName(name);
        p.setDescription(desc);
        p.setPrice(price);
        p.setStock(stock);
        p.setImagePath(imagePath);

        try {
            boolean ok = productDAO.updateProduct(p);
            if (ok) {
                ValidationUtils.showInfo("Success", "Product updated successfully!");
                clearForm();
                loadProductTable();
            } else {
                ValidationUtils.showError("Error", "Failed to update product.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Error: " + ex.getMessage());
        }
    }

    private void deleteProduct() {
        String idStr = txtId.getText().trim();
        if (idStr.isEmpty()) {
            ValidationUtils.showWarning("Selection Required", "Please select a product from the table to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete product '" + txtName.getText() + "'?", 
            "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int id = Integer.parseInt(idStr);
                boolean ok = productDAO.deleteProduct(id);
                if (ok) {
                    ValidationUtils.showInfo("Deleted", "Product deleted successfully.");
                    clearForm();
                    loadProductTable();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                ValidationUtils.showError("Database Error", "Cannot delete product:\n" + ex.getMessage());
            }
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        txtDescription.setText("");
        txtImagePath.setText("");
        if (cmbCategory.getItemCount() > 0) cmbCategory.setSelectedIndex(0);
        updateImagePreview("product_images/espresso.png", "Preview");
        productTable.clearSelection();
    }
}
