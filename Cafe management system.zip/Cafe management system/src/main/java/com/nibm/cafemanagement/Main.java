package com.nibm.cafemanagement;

import com.formdev.flatlaf.FlatLightLaf;
import com.nibm.cafemanagement.config.DBConnection;
import com.nibm.cafemanagement.ui.LoginFrame;
import com.nibm.cafemanagement.util.ImageUtils;

import javax.swing.*;
import java.awt.*;

/**
 * Main application bootstrap for Aura Artisan Cafe Management System.
 * Enterprise Application Development.
 */
public class Main {

    public static void main(String[] args) {
        // 1. Setup Modern FlatLaf Look and Feel
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
            // Global UI customizations
            UIManager.put("Button.arc", 8);
            UIManager.put("Component.arc", 8);
            UIManager.put("TextComponent.arc", 6);
            UIManager.put("ScrollBar.thumbArc", 6);
            UIManager.put("Component.focusWidth", 1);
        } catch (Exception e) {
            System.err.println("Failed to initialize FlatLaf theme, using default: " + e.getMessage());
        }

        // 2. Automatically generate sample product images if they don't exist
        ImageUtils.createSampleProductImages();

        // 3. Check / Pre-warm Database Connection
        new Thread(() -> {
            try {
                DBConnection.getInstance().getConnection();
            } catch (Exception ignored) {}
        }).start();

        // 4. Launch Login Frame on the Swing Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
