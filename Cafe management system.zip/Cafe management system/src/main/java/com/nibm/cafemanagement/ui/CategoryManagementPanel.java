package com.nibm.cafemanagement.ui;

import com.nibm.cafemanagement.dao.CategoryDAO;
import com.nibm.cafemanagement.model.Category;
import com.nibm.cafemanagement.util.ValidationUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class CategoryManagementPanel extends JPanel {

    private final CategoryDAO categoryDAO = new CategoryDAO();

    private JTable categoryTable;
    private DefaultTableModel tableModel;
    private List<Category> categoryList;

    private JTextField txtId;
    private JTextField txtName;
    private JTextArea txtDescription;

    private JButton btnAdd;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;

    public CategoryManagementPanel() {
        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(248, 246, 242));
        setBorder(new EmptyBorder(15, 15, 15, 15));

        initComponents();
        loadCategories();
    }

    private void initComponents() {
        // Top Header
        JPanel topHeader = new JPanel(new BorderLayout());
        topHeader.setOpaque(false);
        JLabel lblHeader = new JLabel("📁 Category Management");
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblHeader.setForeground(new Color(44, 29, 17));
        topHeader.add(lblHeader, BorderLayout.WEST);
        add(topHeader, BorderLayout.NORTH);

        // Center: Left = Form, Right = Table
        JPanel mainContent = new JPanel(new BorderLayout(15, 0));
        mainContent.setOpaque(false);

        // LEFT FORM
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setPreferredSize(new Dimension(320, 0));
        formContainer.setBackground(Color.WHITE);
        formContainer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(225, 220, 215)),
            new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblTitle = new JLabel("Category Details");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitle.setForeground(new Color(44, 29, 17));
        formContainer.add(lblTitle);
        formContainer.add(Box.createVerticalStrut(15));

        txtId = new JTextField();
        txtId.setVisible(false);

        txtName = new JTextField();
        txtDescription = new JTextArea(4, 20);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);

        formContainer.add(createFieldRow("Category Name *:", txtName));
        JScrollPane descScroll = new JScrollPane(txtDescription);
        descScroll.setPreferredSize(new Dimension(240, 80));
        formContainer.add(createFieldRow("Description:", descScroll));

        // Buttons
        JPanel btnRow = new JPanel(new GridLayout(2, 2, 8, 8));
        btnRow.setOpaque(false);
        btnRow.setBorder(new EmptyBorder(15, 0, 0, 0));

        btnAdd = new JButton("Add Category");
        btnAdd.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnAdd.setBackground(new Color(92, 58, 33));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> addCategory());

        btnUpdate = new JButton("Update");
        btnUpdate.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnUpdate.setBackground(new Color(180, 100, 30));
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> updateCategory());

        btnDelete = new JButton("Delete");
        btnDelete.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnDelete.setBackground(new Color(180, 40, 40));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> deleteCategory());

        btnClear = new JButton("Clear");
        btnClear.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnClear.addActionListener(e -> clearForm());

        btnRow.add(btnAdd);
        btnRow.add(btnUpdate);
        btnRow.add(btnDelete);
        btnRow.add(btnClear);

        formContainer.add(Box.createVerticalGlue());
        formContainer.add(btnRow);

        mainContent.add(formContainer, BorderLayout.WEST);

        // RIGHT TABLE
        String[] cols = {"ID", "Category Name", "Description"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };

        categoryTable = new JTable(tableModel);
        categoryTable.setRowHeight(32);
        categoryTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        categoryTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        categoryTable.getColumnModel().getColumn(0).setPreferredWidth(50);
        categoryTable.getColumnModel().getColumn(1).setPreferredWidth(160);
        categoryTable.getColumnModel().getColumn(2).setPreferredWidth(300);

        categoryTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && categoryTable.getSelectedRow() >= 0) {
                populateForm();
            }
        });

        JScrollPane tableScroll = new JScrollPane(categoryTable);
        tableScroll.setBorder(BorderFactory.createLineBorder(new Color(225, 220, 215)));
        mainContent.add(tableScroll, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JPanel createFieldRow(String label, JComponent comp) {
        JPanel p = new JPanel(new BorderLayout(8, 2));
        p.setOpaque(false);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, comp instanceof JScrollPane ? 100 : 45));
        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(l, BorderLayout.NORTH);
        p.add(comp, BorderLayout.CENTER);
        return p;
    }

    private void loadCategories() {
        tableModel.setRowCount(0);
        try {
            categoryList = categoryDAO.getAllCategories();
            for (Category c : categoryList) {
                tableModel.addRow(new Object[]{c.getId(), c.getName(), c.getDescription()});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Database Error", "Failed to load categories: " + ex.getMessage());
        }
    }

    private void populateForm() {
        int row = categoryTable.getSelectedRow();
        if (row < 0 || row >= categoryList.size()) return;

        Category c = categoryList.get(row);
        txtId.setText(String.valueOf(c.getId()));
        txtName.setText(c.getName());
        txtDescription.setText(c.getDescription() != null ? c.getDescription() : "");
    }

    private void addCategory() {
        String name = txtName.getText().trim();
        if (ValidationUtils.isEmpty(name)) {
            ValidationUtils.showWarning("Validation Error", "Category name cannot be empty.");
            return;
        }

        Category c = new Category();
        c.setName(name);
        c.setDescription(txtDescription.getText().trim());

        try {
            boolean ok = categoryDAO.addCategory(c);
            if (ok) {
                ValidationUtils.showInfo("Success", "Category '" + name + "' added successfully!");
                clearForm();
                loadCategories();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Error", "Category may already exist or error: " + ex.getMessage());
        }
    }

    private void updateCategory() {
        String idStr = txtId.getText().trim();
        if (idStr.isEmpty()) {
            ValidationUtils.showWarning("Selection Required", "Please select a category to update.");
            return;
        }

        String name = txtName.getText().trim();
        if (ValidationUtils.isEmpty(name)) {
            ValidationUtils.showWarning("Validation Error", "Category name cannot be empty.");
            return;
        }

        Category c = new Category();
        c.setId(Integer.parseInt(idStr));
        c.setName(name);
        c.setDescription(txtDescription.getText().trim());

        try {
            boolean ok = categoryDAO.updateCategory(c);
            if (ok) {
                ValidationUtils.showInfo("Success", "Category updated successfully!");
                clearForm();
                loadCategories();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ValidationUtils.showError("Error", "Error updating category: " + ex.getMessage());
        }
    }

    private void deleteCategory() {
        String idStr = txtId.getText().trim();
        if (idStr.isEmpty()) {
            ValidationUtils.showWarning("Selection Required", "Please select a category to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, 
            "Deleting this category will also remove its associated products. Proceed?", 
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean ok = categoryDAO.deleteCategory(Integer.parseInt(idStr));
                if (ok) {
                    ValidationUtils.showInfo("Deleted", "Category deleted successfully.");
                    clearForm();
                    loadCategories();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                ValidationUtils.showError("Error", "Cannot delete category: " + ex.getMessage());
            }
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtDescription.setText("");
        categoryTable.clearSelection();
    }
}
