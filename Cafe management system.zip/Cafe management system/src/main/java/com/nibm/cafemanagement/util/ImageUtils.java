package com.nibm.cafemanagement.util;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class ImageUtils {

    private static final Map<String, ImageIcon> cache = new HashMap<>();
    private static final String DEFAULT_IMAGE_DIR = "product_images";

    static {
        File dir = new File(DEFAULT_IMAGE_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public static ImageIcon getProductIcon(String imagePath, int width, int height, String fallbackText) {
        String cacheKey = imagePath + "_" + width + "_" + height;
        if (cache.containsKey(cacheKey)) {
            return cache.get(cacheKey);
        }

        BufferedImage img = null;

        // 1. Try loading from file path
        if (imagePath != null && !imagePath.trim().isEmpty()) {
            File file = new File(imagePath);
            if (file.exists()) {
                try {
                    img = ImageIO.read(file);
                } catch (IOException ignored) {}
            }
        }

        // 2. Try loading from classpath resources
        if (img == null && imagePath != null) {
            String resPath = imagePath.startsWith("/") ? imagePath : "/" + imagePath;
            try (InputStream is = ImageUtils.class.getResourceAsStream(resPath)) {
                if (is != null) {
                    img = ImageIO.read(is);
                }
            } catch (IOException ignored) {}
        }

        // 3. Fallback: Generate custom high-res aesthetic product card graphic dynamically
        if (img == null) {
            img = generatePlaceholderImage(width, height, fallbackText != null ? fallbackText : "Cafe Item");
        }

        Image scaledImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon icon = new ImageIcon(scaledImg);
        cache.put(cacheKey, icon);
        return icon;
    }

    public static BufferedImage generatePlaceholderImage(int width, int height, String title) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Modern cafe gradient background
        Color topColor = new Color(54, 38, 30);
        Color bottomColor = new Color(90, 60, 45);
        GradientPaint gp = new GradientPaint(0, 0, topColor, 0, height, bottomColor);
        g2.setPaint(gp);
        g2.fillRect(0, 0, width, height);

        // Decorative subtle cup / circle pattern
        g2.setColor(new Color(255, 255, 255, 18));
        g2.fillOval(width / 2 - 40, height / 2 - 45, 80, 80);

        // Coffee Cup Vector Graphic
        int cx = width / 2;
        int cy = height / 2 - 10;
        
        g2.setColor(new Color(230, 180, 140));
        // Steam curves
        g2.setStroke(new BasicStroke(2.5f));
        g2.drawArc(cx - 10, cy - 25, 10, 15, 0, 180);
        g2.drawArc(cx + 2, cy - 28, 10, 15, 180, -180);

        // Cup Body
        g2.fillRoundRect(cx - 18, cy - 8, 36, 26, 8, 8);
        // Cup Handle
        g2.drawArc(cx + 12, cy - 4, 12, 16, 270, 180);
        // Saucer
        g2.fillRoundRect(cx - 24, cy + 18, 48, 4, 3, 3);

        // Product Title Text
        g2.setColor(new Color(245, 235, 220));
        g2.setFont(new Font("SansSerif", Font.BOLD, 12));
        FontMetrics fm = g2.getFontMetrics();
        String displayTitle = title.length() > 15 ? title.substring(0, 13) + ".." : title;
        int textX = (width - fm.stringWidth(displayTitle)) / 2;
        int textY = height - 12;
        g2.drawString(displayTitle, textX, textY);

        g2.dispose();
        return img;
    }

    public static void createSampleProductImages() {
        String[] sampleItems = {
            "espresso.png|Classic Espresso|54,38,30",
            "latte.png|Caffe Latte|80,50,35",
            "cappuccino.png|Cappuccino|70,45,30",
            "macchiato.png|Caramel Macchiato|90,55,30",
            "iced_tea.png|Iced Lemon Tea|180,100,30",
            "smoothie.png|Berry Smoothie|160,40,90",
            "croissant.png|Butter Croissant|170,110,40",
            "muffin.png|Blueberry Muffin|110,60,120",
            "cheesecake.png|Chocolate Cake|70,30,20",
            "sandwich.png|Club Sandwich|100,130,50"
        };

        for (String item : sampleItems) {
            String[] parts = item.split("\\|");
            String filename = parts[0];
            String title = parts[1];
            File file = new File(DEFAULT_IMAGE_DIR, filename);
            if (!file.exists()) {
                try {
                    BufferedImage img = generatePlaceholderImage(200, 160, title);
                    ImageIO.write(img, "png", file);
                } catch (IOException ignored) {}
            }
        }
    }
}
