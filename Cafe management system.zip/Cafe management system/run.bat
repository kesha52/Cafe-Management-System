@echo off
title Aura Artisan Cafe Management System
echo ========================================================
echo        AURA ARTISAN CAFE MANAGEMENT & POS SUITE
echo             Enterprise Sales Application
echo ========================================================
echo.
echo Launching application...
echo.

if exist "target\CafeManagementSystem-1.0-SNAPSHOT.jar" (
    java -jar target\CafeManagementSystem-1.0-SNAPSHOT.jar
) else (
    echo [ERROR] JAR file not found. Running Maven build first...
    call mvn clean package -DskipTests
    java -jar target\CafeManagementSystem-1.0-SNAPSHOT.jar
)

pause
