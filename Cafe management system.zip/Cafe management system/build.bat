@echo off
title Build Aura Artisan Cafe Management System
echo ========================================================
echo     Building Aura Artisan Cafe Management System (Maven)
echo ========================================================
echo.

call mvn clean package -DskipTests

if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Build succeeded!
    echo Executable JAR created at: target\CafeManagementSystem-1.0-SNAPSHOT.jar
) else (
    echo.
    echo [ERROR] Build failed. Please inspect logs above.
)

echo.
pause
