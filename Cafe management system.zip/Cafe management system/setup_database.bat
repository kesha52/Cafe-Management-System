@echo off
title Setup Cafe Management Database
echo ========================================================
echo        Setting up MySQL Database (cafe_db)
echo ========================================================
echo.

mysql -u root -pke1234 < schema.sql

if %ERRORLEVEL% EQU 0 (
    echo.
    echo [SUCCESS] Database 'cafe_db' created and seeded successfully!
) else (
    echo.
    echo [WARNING] Could not run with -pke1234. Trying with user prompt...
    mysql -u root -p < schema.sql
)

echo.
pause
